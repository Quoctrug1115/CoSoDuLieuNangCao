BEGIN EXECUTE IMMEDIATE 'DROP TABLE ChiPhiPhuThu CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE LichSuPhong   CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE HoaDon        CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE KhachHang     CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE Phong         CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE SEQ_HD';    EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP VIEW vw_PhongTrong'; EXCEPTION WHEN OTHERS THEN NULL; END;
/


-- ================================================================
--   -  TAO BANG + SEQUENCE
-- ================================================================

CREATE TABLE Phong (
    MaPhong       VARCHAR2(10)  NOT NULL,
    LoaiPhong     VARCHAR2(50)  NOT NULL,
    TrangThai     VARCHAR2(10)  DEFAULT 'TRONG' NOT NULL,
    GiaTheoGio    NUMBER(15,2),
    GiaTheoNgay   NUMBER(15,2)  NOT NULL,
    SoNguoiToiDa  NUMBER(3)     NOT NULL,
    CONSTRAINT pk_phong       PRIMARY KEY (MaPhong),
    CONSTRAINT ck_phong_tt    CHECK (TrangThai IN ('TRONG','DA_THUE','BAO_TRI')),
    CONSTRAINT ck_phong_gio   CHECK (GiaTheoGio IS NULL OR GiaTheoGio > 0),
    CONSTRAINT ck_phong_ngay  CHECK (GiaTheoNgay > 0),
    CONSTRAINT ck_phong_ng    CHECK (SoNguoiToiDa > 0)
);

CREATE TABLE KhachHang (
    MaKH      VARCHAR2(10)   NOT NULL,
    HoTen     VARCHAR2(100)  NOT NULL,
    CCCD      VARCHAR2(20)   NOT NULL,
    SoDT      VARCHAR2(20),
    Email     VARCHAR2(100),
    QuocTich  VARCHAR2(50)   DEFAULT 'Viet Nam',
    CONSTRAINT pk_khachhang PRIMARY KEY (MaKH),
    CONSTRAINT uq_kh_cccd   UNIQUE (CCCD)
);

CREATE TABLE HoaDon (
    MaHD      VARCHAR2(10)   NOT NULL,
    MaKH      VARCHAR2(10)   NOT NULL,
    MaPhong   VARCHAR2(10)   NOT NULL,
    NgayNhan  DATE           NOT NULL,
    NgayTra   DATE           NOT NULL,
    SoNguoi   NUMBER(3)      NOT NULL,
    TongTien  NUMBER(15,2)   DEFAULT 0,
    TrangThai VARCHAR2(10)   DEFAULT 'CHO_NHAN' NOT NULL,
    CONSTRAINT pk_hoadon   PRIMARY KEY (MaHD),
    CONSTRAINT fk_hd_kh    FOREIGN KEY (MaKH)    REFERENCES KhachHang(MaKH),
    CONSTRAINT fk_hd_phong FOREIGN KEY (MaPhong) REFERENCES Phong(MaPhong),
    CONSTRAINT ck_hd_tt    CHECK (TrangThai IN ('CHO_NHAN','DANG_O','DA_TRA','HUY')),
    CONSTRAINT ck_hd_ng    CHECK (SoNguoi > 0)
);

CREATE TABLE ChiPhiPhuThu (
    MaCP     VARCHAR2(10)   NOT NULL,
    MaHD     VARCHAR2(10)   NOT NULL,
    MoTa     VARCHAR2(200),
    SoTien   NUMBER(15,2)   NOT NULL,
    ThoiGian DATE           DEFAULT SYSDATE,
    CONSTRAINT pk_chiphi    PRIMARY KEY (MaCP),
    CONSTRAINT fk_cp_hd     FOREIGN KEY (MaHD) REFERENCES HoaDon(MaHD),
    CONSTRAINT ck_cp_tien   CHECK (SoTien > 0)
);

CREATE TABLE LichSuPhong (
    MaLS     VARCHAR2(10)   NOT NULL,
    MaPhong  VARCHAR2(10)   NOT NULL,
    MaHD     VARCHAR2(10)   NOT NULL,
    NgayNhan DATE,
    NgayTra  DATE,
    GhiChu   VARCHAR2(500),
    CONSTRAINT pk_lichsu   PRIMARY KEY (MaLS),
    CONSTRAINT fk_ls_phong FOREIGN KEY (MaPhong) REFERENCES Phong(MaPhong),
    CONSTRAINT fk_ls_hd    FOREIGN KEY (MaHD)    REFERENCES HoaDon(MaHD)
);

CREATE SEQUENCE SEQ_HD START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;



-- ================================================================
--   -  DU LIEU MAU (5 dong moi bang)
-- ================================================================

-- 5 phong: 3 TRONG, 1 DA_THUE, 1 BAO_TRI de test du case
INSERT INTO Phong VALUES ('P101','Standard', 'TRONG',   100000,  500000, 2);
INSERT INTO Phong VALUES ('P102','Standard', 'TRONG',   100000,  500000, 2);
INSERT INTO Phong VALUES ('P201','Deluxe',   'TRONG',   150000,  800000, 3);
INSERT INTO Phong VALUES ('P202','Deluxe',   'BAO_TRI', 150000,  800000, 3);
INSERT INTO Phong VALUES ('P301','Suite',    'TRONG',   300000, 2000000, 5);

-- 5 khach hang
INSERT INTO KhachHang VALUES ('KH001','Nguyen Minh Tuan','001234567890','0901111111','tuan@gmail.com',  'Viet Nam');
INSERT INTO KhachHang VALUES ('KH002','Tran Thi Lan',    '001234567891','0902222222','lan@gmail.com',   'Viet Nam');
INSERT INTO KhachHang VALUES ('KH003','Le Van Hung',     '001234567892','0903333333','hung@gmail.com',  'Viet Nam');
INSERT INTO KhachHang VALUES ('KH004','John Smith',      'US123456789', '0904444444','john@usa.com',    'My');
INSERT INTO KhachHang VALUES ('KH005','Yuki Tanaka',     'JP987654321', '0905555555','yuki@jp.com',     'Nhat Ban');

COMMIT;
PROMPT >> BUOC 3 hoan tat: 5 phong + 5 khach hang.


-- ================================================================
--   -  PACKAGE CHO COMPOUND TRIGGER (Phieu 3c)
-- ================================================================
CREATE OR REPLACE PACKAGE pkg_chiphi_state AS
    TYPE t_mahd_tab IS TABLE OF HoaDon.MaHD%TYPE INDEX BY BINARY_INTEGER;
    g_row_count  NUMBER      := 0;
    g_mahd_list  t_mahd_tab;
END pkg_chiphi_state;
/


-- ================================================================
--   -  TRIGGER + VIEW
-- ================================================================

-- ---------------------------------------------------------------
-- [Phieu 3A] trg_DatPhong - BEFORE INSERT ON HoaDon
-- ---------------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_DatPhong
BEFORE INSERT ON HoaDon
FOR EACH ROW
DECLARE
    v_kh_count    NUMBER;
    v_phong_count NUMBER;
    v_trangThai   Phong.TrangThai%TYPE;
    v_soNguoiMax  Phong.SoNguoiToiDa%TYPE;
    v_giaTheoNgay Phong.GiaTheoNgay%TYPE;
    v_soNgay      NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_kh_count FROM KhachHang WHERE MaKH = :NEW.MaKH;
    IF v_kh_count = 0 THEN
        RAISE_APPLICATION_ERROR(-20100,
            'trg_DatPhong [ERR-20100]: MaKH [' || :NEW.MaKH || '] khong ton tai.');
    END IF;

    SELECT COUNT(*), MAX(TrangThai), MAX(SoNguoiToiDa), MAX(GiaTheoNgay)
    INTO   v_phong_count, v_trangThai, v_soNguoiMax, v_giaTheoNgay
    FROM   Phong WHERE MaPhong = :NEW.MaPhong;

    IF v_phong_count = 0 THEN
        RAISE_APPLICATION_ERROR(-20101,
            'trg_DatPhong [ERR-20101]: MaPhong [' || :NEW.MaPhong || '] khong ton tai.');
    END IF;

    IF v_trangThai <> 'TRONG' THEN
        RAISE_APPLICATION_ERROR(-20102,
            'trg_DatPhong [ERR-20102]: Phong [' || :NEW.MaPhong
            || '] dang [' || v_trangThai || '], khong the dat.');
    END IF;

    IF :NEW.SoNguoi > v_soNguoiMax THEN
        RAISE_APPLICATION_ERROR(-20103,
            'trg_DatPhong [ERR-20103]: SoNguoi (' || :NEW.SoNguoi
            || ') vuot toi da (' || v_soNguoiMax || ').');
    END IF;

    IF :NEW.NgayNhan >= :NEW.NgayTra THEN
        RAISE_APPLICATION_ERROR(-20104,
            'trg_DatPhong [ERR-20104]: NgayNhan phai < NgayTra.');
    END IF;

    IF TRUNC(:NEW.NgayNhan) < TRUNC(SYSDATE) THEN
        RAISE_APPLICATION_ERROR(-20105,
            'trg_DatPhong [ERR-20105]: NgayNhan khong duoc la qua khu.');
    END IF;

    v_soNgay      := TRUNC(:NEW.NgayTra) - TRUNC(:NEW.NgayNhan);
    :NEW.TongTien := v_soNgay * v_giaTheoNgay;

    UPDATE Phong SET TrangThai = 'DA_THUE' WHERE MaPhong = :NEW.MaPhong;
END trg_DatPhong;
/

-- ---------------------------------------------------------------
-- [Phieu 3B] trg_CapNhatTrangThaiHD - BEFORE UPDATE OF TrangThai
-- ---------------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_CapNhatTrangThaiHD
BEFORE UPDATE OF TrangThai ON HoaDon
FOR EACH ROW
DECLARE
    v_ok BOOLEAN := FALSE;
BEGIN
    IF    :OLD.TrangThai = 'CHO_NHAN' AND :NEW.TrangThai IN ('DANG_O','HUY') THEN v_ok := TRUE;
    ELSIF :OLD.TrangThai = 'DANG_O'   AND :NEW.TrangThai = 'DA_TRA'          THEN v_ok := TRUE;
    ELSIF :OLD.TrangThai IN ('DA_TRA','HUY') THEN
        RAISE_APPLICATION_ERROR(-20110,
            'trg_CTTHD [ERR-20110]: HoaDon [' || :OLD.MaHD
            || '] trang thai [' || :OLD.TrangThai || '] khong duoc thay doi.');
    END IF;

    IF NOT v_ok THEN
        RAISE_APPLICATION_ERROR(-20111,
            'trg_CTTHD [ERR-20111]: Khong the chuyen ['
            || :OLD.TrangThai || '] -> [' || :NEW.TrangThai || '].');
    END IF;

    IF :NEW.TrangThai = 'DA_TRA' THEN
        UPDATE Phong SET TrangThai = 'TRONG' WHERE MaPhong = :OLD.MaPhong;
        INSERT INTO LichSuPhong(MaLS,MaPhong,MaHD,NgayNhan,NgayTra,GhiChu)
        VALUES ('LS'||TO_CHAR(SEQ_HD.NEXTVAL,'FM0000'),
                :OLD.MaPhong,:OLD.MaHD,:OLD.NgayNhan,SYSDATE,
                'Khach tra phong - HD: '||:OLD.MaHD);
    ELSIF :NEW.TrangThai = 'HUY' THEN
        UPDATE Phong SET TrangThai = 'TRONG' WHERE MaPhong = :OLD.MaPhong;
    END IF;
END trg_CapNhatTrangThaiHD;
/

-- ---------------------------------------------------------------
-- [Phieu 3C] trg_SuaChiPhi - Compound Trigger INSERT/UPDATE ON ChiPhiPhuThu
-- ---------------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_SuaChiPhi
FOR INSERT OR UPDATE ON ChiPhiPhuThu
COMPOUND TRIGGER

    BEFORE STATEMENT IS
    BEGIN
        pkg_chiphi_state.g_row_count := 0;
        pkg_chiphi_state.g_mahd_list.DELETE;
    END BEFORE STATEMENT;

    BEFORE EACH ROW IS
    BEGIN
        pkg_chiphi_state.g_row_count := pkg_chiphi_state.g_row_count + 1;

        IF pkg_chiphi_state.g_row_count > 5 THEN
            RAISE_APPLICATION_ERROR(-20120,
                'trg_SuaChiPhi [ERR-20120]: Chi duoc INSERT/UPDATE toi da 5 chi phi moi lenh.');
        END IF;
        IF :NEW.SoTien <= 0 THEN
            RAISE_APPLICATION_ERROR(-20121,
                'trg_SuaChiPhi [ERR-20121]: SoTien phai > 0.');
        END IF;
        IF :NEW.SoTien >= 50000000 THEN
            RAISE_APPLICATION_ERROR(-20122,
                'trg_SuaChiPhi [ERR-20122]: SoTien phai < 50,000,000 dong.');
        END IF;

        pkg_chiphi_state.g_mahd_list(pkg_chiphi_state.g_row_count) := :NEW.MaHD;
    END BEFORE EACH ROW;

    AFTER STATEMENT IS
        v_tong_chiphi  NUMBER;
        v_tong_phong   NUMBER;
        v_mahd         HoaDon.MaHD%TYPE;
        TYPE t_set IS TABLE OF NUMBER INDEX BY VARCHAR2(10);
        v_set  t_set;
    BEGIN
        FOR i IN 1 .. pkg_chiphi_state.g_mahd_list.COUNT LOOP
            v_set(pkg_chiphi_state.g_mahd_list(i)) := 1;
        END LOOP;
        v_mahd := v_set.FIRST;
        WHILE v_mahd IS NOT NULL LOOP
            SELECT NVL(SUM(SoTien),0) INTO v_tong_chiphi
            FROM ChiPhiPhuThu WHERE MaHD = v_mahd;

            SELECT (TRUNC(h.NgayTra)-TRUNC(h.NgayNhan)) * p.GiaTheoNgay + v_tong_chiphi
            INTO   v_tong_phong
            FROM HoaDon h JOIN Phong p ON p.MaPhong = h.MaPhong
            WHERE h.MaHD = v_mahd;

            UPDATE HoaDon SET TongTien = v_tong_phong WHERE MaHD = v_mahd;
            v_mahd := v_set.NEXT(v_mahd);
        END LOOP;
    END AFTER STATEMENT;

END trg_SuaChiPhi;
/

-- ---------------------------------------------------------------
-- [Phieu 3D] View vw_PhongTrong + INSTEAD OF Trigger
-- ---------------------------------------------------------------
CREATE OR REPLACE VIEW vw_PhongTrong AS
SELECT MaPhong, LoaiPhong, TrangThai, GiaTheoGio, GiaTheoNgay, SoNguoiToiDa
FROM Phong WHERE TrangThai = 'TRONG';

CREATE OR REPLACE TRIGGER trg_vwPhongTrong_ins
INSTEAD OF INSERT ON vw_PhongTrong
FOR EACH ROW
DECLARE
    v_maHD  VARCHAR2(10);
    v_maKH  KhachHang.MaKH%TYPE;
BEGIN
    v_maHD := 'HD' || TO_CHAR(SEQ_HD.NEXTVAL, 'FM0000');
    SELECT MIN(MaKH) INTO v_maKH FROM KhachHang;
    IF v_maKH IS NULL THEN
        RAISE_APPLICATION_ERROR(-20130,
            'trg_vwPhongTrong [ERR-20130]: Khong co khach hang trong he thong.');
    END IF;
    INSERT INTO HoaDon(MaHD,MaKH,MaPhong,NgayNhan,NgayTra,SoNguoi,TongTien,TrangThai)
    VALUES (v_maHD, v_maKH, :NEW.MaPhong,
            TRUNC(SYSDATE)+1, TRUNC(SYSDATE)+2, 1, 0, 'CHO_NHAN');
    DBMS_OUTPUT.PUT_LINE('  >> Da tao hoa don: '||v_maHD||' cho phong: '||:NEW.MaPhong);
END trg_vwPhongTrong_ins;
/



-- ================================================================
--   -  TEST CASES
-- ================================================================

PROMPT;
PROMPT ============================================================
PROMPT  PHIEU 3A: trg_DatPhong
PROMPT ============================================================

PROMPT [CHECK] Phong ban dau (P101,P102,P201,P301=TRONG | P202=BAO_TRI):
SELECT MaPhong, LoaiPhong, TrangThai, GiaTheoNgay, SoNguoiToiDa FROM Phong ORDER BY MaPhong;

PROMPT;
PROMPT [OK] KH001 dat P101 – 2 nguoi – 3 ngay – TongTien = 3x500000 = 1,500,000:
INSERT INTO HoaDon(MaHD,MaKH,MaPhong,NgayNhan,NgayTra,SoNguoi,TongTien,TrangThai)
VALUES ('HD001','KH001','P101',TRUNC(SYSDATE)+1,TRUNC(SYSDATE)+4,2,0,'CHO_NHAN');
COMMIT;

PROMPT;
PROMPT [CHECK] TongTien tu tinh + TrangThai phong:
SELECT h.MaHD, h.MaKH, h.MaPhong,
       TRUNC(h.NgayTra)-TRUNC(h.NgayNhan) AS SoNgay,
       h.TongTien,
       h.TrangThai AS TT_HD,
       p.TrangThai AS TT_Phong
FROM HoaDon h JOIN Phong p ON p.MaPhong = h.MaPhong
ORDER BY h.MaHD;
-- Ky vong TongTien: HD001=1500000 | HD002=1000000 | HD003=4000000 | HD004=4000000

PROMPT;
PROMPT [ERR-20100] MaKH khong ton tai -> ORA-20100:
BEGIN
    INSERT INTO HoaDon VALUES ('ERR01','KH_FAKE','P101',TRUNC(SYSDATE)+1,TRUNC(SYSDATE)+2,1,0,'CHO_NHAN');
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('  >> '||SQLERRM); END;
/
PROMPT;
PROMPT ============================================================
PROMPT  PHIEU 3B: trg_CapNhatTrangThaiHD (State Machine)
PROMPT ============================================================

PROMPT [CHECK] Trang thai hien tai:
SELECT MaHD, TrangThai FROM HoaDon ORDER BY MaHD;

PROMPT;
PROMPT [OK] HD001: CHO_NHAN → DANG_O:
UPDATE HoaDon SET TrangThai = 'DANG_O' WHERE MaHD = 'HD001';
COMMIT;
SELECT MaHD, TrangThai FROM HoaDon WHERE MaHD = 'HD001';

PROMPT;
PROMPT [ERR-20110] DA_TRA khong duoc doi (HD001) -> ORA-20110:
BEGIN UPDATE HoaDon SET TrangThai='DANG_O' WHERE MaHD='HD001';
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('  >> '||SQLERRM); END;
/
PROMPT;
PROMPT ============================================================
PROMPT  PHIEU 3C: trg_SuaChiPhi (Compound Trigger)
PROMPT ============================================================
-- HD003, HD004 dang DANG_O - dung de test

PROMPT [CHECK] TongTien truoc them chi phi (HD003 ky vong 4,000,000):
SELECT MaHD, TongTien FROM HoaDon WHERE MaHD IN ('HD003','HD004');

PROMPT;
PROMPT [OK] 1 chi phi cho HD003 – 200,000:
INSERT INTO ChiPhiPhuThu VALUES ('CP001','HD003','Giat do',     200000,SYSDATE);
COMMIT;
SELECT MaHD, TongTien AS TongTien_Sau FROM HoaDon WHERE MaHD='HD003';
-- Ky vong: 4000000 + 200000 = 4200000


PROMPT;
PROMPT ============================================================
PROMPT  PHIEU 3D: INSTEAD OF Trigger – vw_PhongTrong
PROMPT ============================================================

PROMPT [CHECK] Phong hien TRONG (sau khi HD001=DA_TRA, HD002=HUY → P101,P102 ve TRONG):
SELECT MaPhong, LoaiPhong, GiaTheoNgay, SoNguoiToiDa FROM vw_PhongTrong;

PROMPT;
PROMPT [OK] Dat P101 qua view -> tao HD tu dong:
INSERT INTO vw_PhongTrong(MaPhong) VALUES ('P101');
COMMIT;

PROMPT [CHECK] Phong sau dat qua view:
SELECT MaPhong, TrangThai FROM Phong ORDER BY MaPhong;
-- Ky vong: P101=DA_THUE | P102=DA_THUE

PROMPT ============================================================
PROMPT  TONG KET CUOI – QL_KHACHSAN
PROMPT ============================================================
PROMPT -- Bang Phong:
SELECT MaPhong, LoaiPhong, TrangThai FROM Phong ORDER BY MaPhong;

PROMPT -- Bang HoaDon:
SELECT MaHD, MaKH, MaPhong, TongTien, TrangThai FROM HoaDon ORDER BY MaHD;

PROMPT -- LichSuPhong:
SELECT MaLS, MaPhong, MaHD, GhiChu FROM LichSuPhong;

PROMPT -- ChiPhiPhuThu:
SELECT MaCP, MaHD, MoTa, SoTien FROM ChiPhiPhuThu ORDER BY MaHD, MaCP;
