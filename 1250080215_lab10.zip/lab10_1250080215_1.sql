
-- Hãng sản xuất
INSERT INTO HangSX VALUES ('HG001','Samsung',  'Seoul, Han Quoc',  '02-1234-5678', 'contact@samsung.com');
INSERT INTO HangSX VALUES ('HG002','Apple',    'Cupertino, My',    '1-800-275-2273','contact@apple.com');
INSERT INTO HangSX VALUES ('HG003','Sony',     'Tokyo, Nhat Ban',  '03-6748-2111', 'contact@sony.com');
INSERT INTO HangSX VALUES ('HG004','LG',       'Seoul, Han Quoc',  '02-3777-7777', 'contact@lg.com');
INSERT INTO HangSX VALUES ('HG005','Xiaomi',   'Bac Kinh, TQ',     '400-100-5678', 'contact@xiaomi.com');

-- San pham (SoLuong = 0, trigger cap nhat khi nhap hang)
INSERT INTO SanPham VALUES ('SP001','HG001','Samsung Galaxy S24',   0,'Den',      22000000,'Cai','Dien thoai cao cap Samsung');
INSERT INTO SanPham VALUES ('SP002','HG002','iPhone 15 Pro',        0,'Titan',    28000000,'Cai','iPhone cao cap nhat 2023');
INSERT INTO SanPham VALUES ('SP003','HG003','Sony WH-1000XM5',      0,'Den',       8500000,'Cai','Tai nghe chong on hang dau');
INSERT INTO SanPham VALUES ('SP004','HG004','LG OLED C3 55',        0,'Den',      35000000,'Cai','TV OLED 4K 55 inch');
INSERT INTO SanPham VALUES ('SP005','HG005','Xiaomi Redmi Note 13', 0,'Xanh',     5500000,'Cai','Dien thoai tam trung 5G');

-- Nhan vien
INSERT INTO NhanVien VALUES ('NV001','Nguyen Van An',  'Nam','123 Le Loi, Q1, HCM',      '0912000001','an@cty.com',   'Kho');
INSERT INTO NhanVien VALUES ('NV002','Tran Thi Binh',  'Nu', '456 Nguyen Trai, Q5, HCM', '0912000002','binh@cty.com', 'Kho');
INSERT INTO NhanVien VALUES ('NV003','Le Minh Cuong',  'Nam','789 Hoang Dieu, Q4, HCM',  '0912000003','cuong@cty.com','Ban hang');
INSERT INTO NhanVien VALUES ('NV004','Pham Thu Dung',  'Nu', '321 Dinh Tien Hoang, BT',  '0912000004','dung@cty.com', 'Ban hang');
INSERT INTO NhanVien VALUES ('NV005','Hoang Duc Em',   'Nam','654 Phan Xich Long, PN',   '0912000005','em@cty.com',   'Quan ly');

-- Phieu nhap header (5 phieu)
INSERT INTO PNhap VALUES ('HDN001', DATE '2024-01-10', 'NV001');
INSERT INTO PNhap VALUES ('HDN002', DATE '2024-01-20', 'NV001');
INSERT INTO PNhap VALUES ('HDN003', DATE '2024-02-05', 'NV002');
INSERT INTO PNhap VALUES ('HDN004', DATE '2024-02-15', 'NV002');
INSERT INTO PNhap VALUES ('HDN005', DATE '2024-03-01', 'NV001');

-- Phieu xuat header (5 phieu)
INSERT INTO PXuat VALUES ('HDX001', DATE '2024-01-25', 'NV003');
INSERT INTO PXuat VALUES ('HDX002', DATE '2024-02-01', 'NV003');
INSERT INTO PXuat VALUES ('HDX003', DATE '2024-02-10', 'NV004');
INSERT INTO PXuat VALUES ('HDX004', DATE '2024-02-20', 'NV004');
INSERT INTO PXuat VALUES ('HDX005', DATE '2024-03-10', 'NV003');

COMMIT;


-- ================================================================
--  –  PACKAGE pkg_state (Compound Trigger – Phiếu 2)
-- ================================================================
CREATE OR REPLACE PACKAGE pkg_state AS
    row_count_xuat  NUMBER := 0;
    row_count_nhap  NUMBER := 0;
END pkg_state;
/


-- ================================================================
--  –  TRIGGER
-- ================================================================

-- ────────────────────────────────────────────────────────────
-- [Phiếu 1A] trg_Nhap – BEFORE INSERT ON Nhap
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE TRIGGER trg_Nhap
BEFORE INSERT ON Nhap
FOR EACH ROW
DECLARE
    v_count  NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count FROM SanPham WHERE MaSP = :NEW.MaSP;
    IF v_count = 0 THEN
        RAISE_APPLICATION_ERROR(-20001,
            'trg_Nhap [ERR-20001]: MaSP [' || :NEW.MaSP || '] khong ton tai.');
    END IF;

    IF :NEW.SoLuongN <= 0 THEN
        RAISE_APPLICATION_ERROR(-20002,
            'trg_Nhap [ERR-20002]: SoLuongN phai > 0, nhan: ' || :NEW.SoLuongN);
    END IF;

    IF :NEW.DonGiaN <= 0 THEN
        RAISE_APPLICATION_ERROR(-20003,
            'trg_Nhap [ERR-20003]: DonGiaN phai > 0, nhan: ' || :NEW.DonGiaN);
    END IF;

    UPDATE SanPham SET SoLuong = SoLuong + :NEW.SoLuongN WHERE MaSP = :NEW.MaSP;
END trg_Nhap;
/

-- ────────────────────────────────────────────────────────────
-- [Phiếu 1B] trg_Xuat – BEFORE INSERT ON Xuat
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE TRIGGER trg_Xuat
BEFORE INSERT ON Xuat
FOR EACH ROW
DECLARE
    v_count    NUMBER;
    v_soLuong  NUMBER;
BEGIN
    SELECT COUNT(*), NVL(MAX(SoLuong), 0)
    INTO   v_count, v_soLuong
    FROM   SanPham WHERE MaSP = :NEW.MaSP;

    IF v_count = 0 THEN
        RAISE_APPLICATION_ERROR(-20010,
            'trg_Xuat [ERR-20010]: MaSP [' || :NEW.MaSP || '] khong ton tai.');
    END IF;

    IF :NEW.SoLuongX > v_soLuong THEN
        RAISE_APPLICATION_ERROR(-20011,
            'trg_Xuat [ERR-20011]: Ton kho khong du. '
            || 'Yeu cau: ' || :NEW.SoLuongX || ' | Con lai: ' || v_soLuong);
    END IF;

    UPDATE SanPham SET SoLuong = SoLuong - :NEW.SoLuongX WHERE MaSP = :NEW.MaSP;
END trg_Xuat;
/

-- ────────────────────────────────────────────────────────────
-- [Phiếu 1C] trg_XoaXuat – AFTER DELETE ON Xuat
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE TRIGGER trg_XoaXuat
AFTER DELETE ON Xuat
FOR EACH ROW
BEGIN
    UPDATE SanPham SET SoLuong = SoLuong + :OLD.SoLuongX WHERE MaSP = :OLD.MaSP;
END trg_XoaXuat;
/

-- ────────────────────────────────────────────────────────────
-- [Phiếu 2A] trg_CapNhatXuat – Compound FOR UPDATE ON Xuat
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE TRIGGER trg_CapNhatXuat
FOR UPDATE ON Xuat
COMPOUND TRIGGER

    BEFORE STATEMENT IS
    BEGIN
        pkg_state.row_count_xuat := 0;
    END BEFORE STATEMENT;

    BEFORE EACH ROW IS
        v_soLuong  NUMBER;
        v_delta    NUMBER;
    BEGIN
        pkg_state.row_count_xuat := pkg_state.row_count_xuat + 1;

        IF pkg_state.row_count_xuat > 1 THEN
            RAISE_APPLICATION_ERROR(-20020,
                'trg_CapNhatXuat [ERR-20020]: Chi duoc UPDATE 1 dong moi lenh XUAT.');
        END IF;

        IF UPDATING('SoLuongX') AND :NEW.SoLuongX <> :OLD.SoLuongX THEN
            v_delta := :NEW.SoLuongX - :OLD.SoLuongX;

            SELECT NVL(SoLuong, 0) INTO v_soLuong FROM SanPham WHERE MaSP = :NEW.MaSP;

            IF v_delta > 0 AND v_soLuong < v_delta THEN
                RAISE_APPLICATION_ERROR(-20021,
                    'trg_CapNhatXuat [ERR-20021]: Ton kho khong du. '
                    || 'Can them: ' || v_delta || ' | Con: ' || v_soLuong);
            END IF;

            UPDATE SanPham SET SoLuong = SoLuong - v_delta WHERE MaSP = :NEW.MaSP;
        END IF;
    END BEFORE EACH ROW;

END trg_CapNhatXuat;
/

-- ────────────────────────────────────────────────────────────
-- [Phiếu 2B] trg_CapNhatNhap – Compound FOR UPDATE ON Nhap
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE TRIGGER trg_CapNhatNhap
FOR UPDATE ON Nhap
COMPOUND TRIGGER

    BEFORE STATEMENT IS
    BEGIN
        pkg_state.row_count_nhap := 0;
    END BEFORE STATEMENT;

    BEFORE EACH ROW IS
        v_delta  NUMBER;
    BEGIN
        pkg_state.row_count_nhap := pkg_state.row_count_nhap + 1;

        IF pkg_state.row_count_nhap > 1 THEN
            RAISE_APPLICATION_ERROR(-20030,
                'trg_CapNhatNhap [ERR-20030]: Chi duoc UPDATE 1 dong moi lenh NHAP.');
        END IF;

        IF UPDATING('SoLuongN') AND :NEW.SoLuongN <> :OLD.SoLuongN THEN
            v_delta := :NEW.SoLuongN - :OLD.SoLuongN;
            UPDATE SanPham SET SoLuong = SoLuong + v_delta WHERE MaSP = :NEW.MaSP;
        END IF;
    END BEFORE EACH ROW;

END trg_CapNhatNhap;
/

-- ────────────────────────────────────────────────────────────
-- [Phiếu 2C] trg_XoaNhap – AFTER DELETE ON Nhap
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE TRIGGER trg_XoaNhap
AFTER DELETE ON Nhap
FOR EACH ROW
BEGIN
    UPDATE SanPham SET SoLuong = SoLuong - :OLD.SoLuongN WHERE MaSP = :OLD.MaSP;
END trg_XoaNhap;
/



-- ================================================================
–-  TEST CASES
-- ================================================================

PROMPT;
PROMPT ============================================================
PROMPT  PHIEU 1A: trg_Nhap
PROMPT ============================================================


SELECT MaSP, TenSP, SoLuong FROM SanPham ORDER BY MaSP;


INSERT INTO Nhap VALUES ('HDN001','SP001', 50, 20000000);
COMMIT;
SELECT MaSP, SoLuong FROM SanPham WHERE MaSP = 'SP001';
-- Ky vong: 50


INSERT INTO Nhap VALUES ('HDN002','SP002', 30, 25000000);
COMMIT;
SELECT MaSP, SoLuong FROM SanPham WHERE MaSP = 'SP002';
-- Ky vong: 30


INSERT INTO Nhap VALUES ('HDN003','SP003', 80, 8000000);
COMMIT;

INSERT INTO Nhap VALUES ('HDN004','SP004', 20, 32000000);
COMMIT;


INSERT INTO Nhap VALUES ('HDN005','SP005', 100, 5000000);
COMMIT;


SELECT MaSP, TenSP, SoLuong AS TonKho_SauNhap FROM SanPham ORDER BY MaSP;

BEGIN
    INSERT INTO Nhap VALUES ('HDN001','SP_GHOST', 10, 50000);
EXCEPTION WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('  >> Bat duoc loi: ' || SQLERRM);
END;
/

PROMPT ============================================================
PROMPT  PHIEU 1B: trg_Xuat
PROMPT ============================================================


PROMPT [OK-5] Xuat SP005: 40 cai (con lai 60):
INSERT INTO Xuat VALUES ('HDX005','SP005', 40);
COMMIT;

PROMPT [CHECK] Ton kho sau xuat (ky vong: 40|25|60|17|60):
SELECT MaSP, TenSP, SoLuong AS TonKho_SauXuat FROM SanPham ORDER BY MaSP;


BEGIN
    INSERT INTO Xuat VALUES ('HDX001','SP001', 999);
EXCEPTION WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('  >> Bat duoc loi: ' || SQLERRM);
END;
/
PROMPT ============================================================
PROMPT  PHIEU 1C: trg_XoaXuat
PROMPT ============================================================

PROMPT [CHECK] Ton kho truoc khi xoa phieu xuat:
SELECT MaSP, SoLuong AS TruocKhiXoa FROM SanPham WHERE MaSP IN ('SP001','SP002');
-- SP001=40, SP002=25


DELETE FROM Xuat WHERE SoHDX = 'HDX001' AND MaSP = 'SP001';
COMMIT;


SELECT MaSP, TenSP, SoLuong AS TonKho_SauHoanTra FROM SanPham ORDER BY MaSP;



PROMPT ============================================================
PROMPT  PHIEU 2A: trg_CapNhatXuat (Compound Trigger)
PROMPT ============================================================
-- Tao lai du lieu xuat de test
INSERT INTO Xuat VALUES ('HDX001','SP001', 10);
INSERT INTO Xuat VALUES ('HDX002','SP002',  5);
INSERT INTO Xuat VALUES ('HDX003','SP003', 20);
INSERT INTO Xuat VALUES ('HDX004','SP004',  3);
INSERT INTO Xuat VALUES ('HDX005','SP005', 40);
COMMIT;


SELECT x.SoHDX, x.MaSP, x.SoLuongX, s.SoLuong AS TonKho
FROM Xuat x JOIN SanPham s ON s.MaSP = x.MaSP WHERE x.SoHDX = 'HDX003';

UPDATE Xuat SET SoLuongX = SoLuongX + 10 WHERE SoHDX = 'HDX003' AND MaSP = 'SP003';
COMMIT;
SELECT s.SoLuong AS TonKho_SauTang FROM SanPham s WHERE MaSP = 'SP003';
