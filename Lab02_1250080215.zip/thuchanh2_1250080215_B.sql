Create Table phongban (
    maphg        Number(2)      Constraint pk_phongban   Primary Key,
    tenphg       Nvarchar2(35),
    manv_truong  Char(9),                                       -- FK thêm sau (circular)
    ng_nhanchuc  Date
);

Create Table nhanvien (
    manv      Char(9)       Constraint pk_nhanvien  Primary Key,
    ho        Nvarchar2(20),
    ten       Nvarchar2(10),
    ngaysinh  Date,
    diachi    Nvarchar2(50),
    phai      Nvarchar2(3),
    luong     Number(8,2),
    ma_nql    Char(9)       Constraint fk_nv_nql    References nhanvien(manv),
    maphg     Number(2)     Constraint fk_nv_phg    References phongban(maphg)
);

Alter Table phongban
    Add Constraint fk_phg_truong Foreign Key (manv_truong)
        References nhanvien(manv);

Create Table diadiem_phg (
    maphg    Number(2)     Constraint fk_dd_phg References phongban(maphg),
    diadiem  Nvarchar2(35),
    Constraint pk_diadiem Primary Key (maphg, diadiem)
);

Create Table dean (
    mada        Number(4)      Constraint pk_dean      Primary Key,
    tenda       Nvarchar2(40),
    diadiem_da  Nvarchar2(35),
    maphg       Number(2)      Constraint fk_da_phg    References phongban(maphg)
);

Create Table phancong (
    manv   Char(9)   Constraint fk_pc_nv References nhanvien(manv),
    mada   Number(4) Constraint fk_pc_da References dean(mada),
    sogio  Number(5,1),
    Constraint pk_phancong Primary Key (manv, mada)
);

Create Table thannhan (
    manv      Char(9)      Constraint fk_tn_nv References nhanvien(manv),
    tentn     Nvarchar2(30),
    phai      Nvarchar2(3),
    ngaysinh  Date,
    quanhe    Nvarchar2(15),
    Constraint pk_thannhan Primary Key (manv, tentn)
);


Insert Into phongban(maphg, tenphg) Values (1, N'Nghiên cứu');
Insert Into phongban(maphg, tenphg) Values (2, N'Hành chính');
Insert Into phongban(maphg, tenphg) Values (3, N'Quản lý dự án');
Insert Into phongban(maphg, tenphg) Values (4, N'Kỹ thuật');
Insert Into phongban(maphg, tenphg) Values (5, N'Kinh doanh');

Insert Into nhanvien Values ('NV001', N'Nguyễn Văn', N'Hùng',    To_date('15/05/1975','DD/MM/YYYY'), N'12 Lê Lợi, Q1, TP.HCM',          N'Nam', 25000000, Null,    1);
Insert Into nhanvien Values ('NV003', N'Lê Văn',     N'Bình',    To_date('10/03/1982','DD/MM/YYYY'), N'78 Trần Phú, Đà Nẵng',             N'Nam', 20000000, 'NV001', 2);
Insert Into nhanvien Values ('NV004', N'Phạm Thị',   N'Lan',     To_date('05/12/1985','DD/MM/YYYY'), N'34 Bà Triệu, Hà Nội',              N'Nữ',  22000000, 'NV001', 3);
Insert Into nhanvien Values ('NV009', N'Đỗ Quang',   N'Hải',     To_date('07/06/1986','DD/MM/YYYY'), N'11 Ngô Quyền, Hà Nội',             N'Nam', 17000000, 'NV001', 4);
Insert Into nhanvien Values ('NV011', N'Trịnh Văn',  N'Khoa',    To_date('03/02/1984','DD/MM/YYYY'), N'19 Hai Bà Trưng, TP.HCM',         N'Nam', 19000000, 'NV001', 5);
Insert Into nhanvien Values ('NV002', N'Trần Thị',   N'Mai',     To_date('20/08/1980','DD/MM/YYYY'), N'45 Nguyễn Huệ, Q1, TP.HCM',       N'Nữ',  18000000, 'NV001', 1);
Insert Into nhanvien Values ('NV005', N'Hoàng Minh', N'Tuấn',    To_date('22/07/1983','DD/MM/YYYY'), N'56 Lý Tự Trọng, TP.HCM',          N'Nam', 16000000, 'NV003', 2);
Insert Into nhanvien Values ('NV006', N'Đặng Thị',   N'Hoa',     To_date('14/01/1988','DD/MM/YYYY'), N'90 Pasteur, Q3, TP.HCM',          N'Nữ',  15000000, 'NV003', 2);
Insert Into nhanvien Values ('NV007', N'Vũ Đức',     N'Long',    To_date('30/09/1979','DD/MM/YYYY'), N'23 Đinh Tiên Hoàng, TP.HCM',      N'Nam', 21000000, 'NV004', 3);
Insert Into nhanvien Values ('NV008', N'Bùi Thị',    N'Nga',     To_date('18/04/1990','DD/MM/YYYY'), N'67 Cách Mạng T8, TP.HCM',         N'Nữ',  14000000, 'NV004', 3);
Insert Into nhanvien Values ('NV010', N'Ngô Thị',    N'Thảo',    To_date('25/11/1992','DD/MM/YYYY'), N'88 Trường Chinh, TP.HCM',         N'Nữ',  13000000, 'NV009', 4);
Insert Into nhanvien Values ('NV012', N'Lý Thị',     N'Vân',     To_date('11/08/1987','DD/MM/YYYY'), N'55 Điện Biên Phủ, TP.HCM',        N'Nữ',  16000000, 'NV011', 5);
Insert Into nhanvien Values ('NV013', N'Mai Văn',    N'Đức',     To_date('28/10/1981','DD/MM/YYYY'), N'33 Lê Thánh Tôn, Q1, TP.HCM',    N'Nam', 15000000, 'NV011', 5);
Insert Into nhanvien Values ('NV014', N'Cao Thị',    N'Linh',    To_date('16/03/1993','DD/MM/YYYY'), N'72 Võ Văn Tần, Q3, TP.HCM',      N'Nữ',  12000000, 'NV002', 1);
Insert Into nhanvien Values ('NV015', N'Đinh Văn',   N'Phúc',    To_date('09/07/1989','DD/MM/YYYY'), N'44 Nam Kỳ Khởi Nghĩa, Q3',        N'Nam', 14000000, 'NV002', 1);
Insert Into nhanvien Values ('NV016', N'Hồ Thị',     N'Thu',     To_date('21/01/1991','DD/MM/YYYY'), N'15 Lê Duẩn, Q1, TP.HCM',         N'Nữ',  13500000, 'NV009', 4);
Insert Into nhanvien Values ('NV017', N'Phan Văn',   N'Tài',     To_date('06/05/1978','DD/MM/YYYY'), N'27 Nguyễn Thị Minh Khai, Q3',    N'Nam', 23000000, 'NV001', 3);
Insert Into nhanvien Values ('NV018', N'Tô Thị',     N'Kim',     To_date('14/09/1995','DD/MM/YYYY'), N'38 Nguyễn Đình Chiểu, Q3',        N'Nữ',  11000000, 'NV012', 5);
Insert Into nhanvien Values ('NV019', N'Dương Văn',  N'Sáng',    To_date('02/12/1983','DD/MM/YYYY'), N'61 Calmette, Q1, TP.HCM',         N'Nam', 18500000, 'NV007', 3);
Insert Into nhanvien Values ('NV020', N'Chu Thị',    N'Ánh',     To_date('30/06/1994','DD/MM/YYYY'), N'9 Phó Đức Chính, Q1, TP.HCM',    N'Nữ',  12500000, 'NV013', 5);

Update phongban Set manv_truong='NV001', ng_nhanchuc=To_date('01/01/2010','DD/MM/YYYY') Where maphg=1;
Update phongban Set manv_truong='NV003', ng_nhanchuc=To_date('15/03/2012','DD/MM/YYYY') Where maphg=2;
Update phongban Set manv_truong='NV004', ng_nhanchuc=To_date('01/06/2013','DD/MM/YYYY') Where maphg=3;
Update phongban Set manv_truong='NV009', ng_nhanchuc=To_date('20/08/2015','DD/MM/YYYY') Where maphg=4;
Update phongban Set manv_truong='NV011', ng_nhanchuc=To_date('10/01/2016','DD/MM/YYYY') Where maphg=5;

Insert Into diadiem_phg Values (1, N'TP. Hồ Chí Minh');
Insert Into diadiem_phg Values (1, N'Hà Nội');
Insert Into diadiem_phg Values (2, N'TP. Hồ Chí Minh');
Insert Into diadiem_phg Values (3, N'Đà Nẵng');
Insert Into diadiem_phg Values (3, N'TP. Hồ Chí Minh');
Insert Into diadiem_phg Values (4, N'TP. Hồ Chí Minh');
Insert Into diadiem_phg Values (5, N'Hà Nội');

Insert Into dean Values (1001, N'Hệ thống ERP nội bộ',        N'TP. Hồ Chí Minh', 3);
Insert Into dean Values (1002, N'Ứng dụng mobile bán hàng',   N'Hà Nội',            3);
Insert Into dean Values (1003, N'Nâng cấp hạ tầng mạng',      N'TP. Hồ Chí Minh', 4);
Insert Into dean Values (1004, N'Nghiên cứu AI sản xuất',      N'Đà Nẵng',          1);
Insert Into dean Values (1005, N'Chiến dịch marketing Q3',    N'TP. Hồ Chí Minh', 5);
Insert Into dean Values (1006, N'Phần mềm kế toán v2',        N'Hà Nội',            2);
Insert Into dean Values (1007, N'Hệ thống CRM',               N'TP. Hồ Chí Minh', 3);
Insert Into dean Values (1008, N'Bảo mật dữ liệu',            N'TP. Hồ Chí Minh', 4);
Insert Into dean Values (1009, N'Phân tích Big Data khách hàng',N'Hà Nội',         1);
Insert Into dean Values (1010, N'Website thương mại điện tử', N'TP. Hồ Chí Minh', 5);

Insert Into phancong Values ('NV007', 1001, 20.0);
Insert Into phancong Values ('NV008', 1001, 15.5);
Insert Into phancong Values ('NV019', 1001, 10.0);
Insert Into phancong Values ('NV002', 1002, 25.0);
Insert Into phancong Values ('NV014', 1002, 20.0);
Insert Into phancong Values ('NV009', 1003, 30.0);
Insert Into phancong Values ('NV010', 1003, 25.0);
Insert Into phancong Values ('NV016', 1003, 20.0);
Insert Into phancong Values ('NV001', 1004,  5.0);
Insert Into phancong Values ('NV015', 1004, 35.0);
Insert Into phancong Values ('NV012', 1005, 20.0);
Insert Into phancong Values ('NV013', 1005, 20.0);
Insert Into phancong Values ('NV020', 1005, 15.0);
Insert Into phancong Values ('NV005', 1006, 30.0);
Insert Into phancong Values ('NV006', 1006, 30.0);
Insert Into phancong Values ('NV004', 1007, 10.0);
Insert Into phancong Values ('NV017', 1007, 25.0);
Insert Into phancong Values ('NV009', 1008, 10.0);
Insert Into phancong Values ('NV011', 1009, 15.0);
Insert Into phancong Values ('NV018', 1010, 40.0);

Insert Into thannhan Values ('NV001', N'Nguyễn Thị Lan',   N'Nữ',  To_date('12/06/1978','DD/MM/YYYY'), N'Vợ');
Insert Into thannhan Values ('NV001', N'Nguyễn Văn Nam',   N'Nam', To_date('05/09/2005','DD/MM/YYYY'), N'Con');
Insert Into thannhan Values ('NV001', N'Nguyễn Thị Mai',   N'Nữ',  To_date('10/01/2008','DD/MM/YYYY'), N'Con');
Insert Into thannhan Values ('NV002', N'Trần Văn Bảo',     N'Nam', To_date('18/03/1979','DD/MM/YYYY'), N'Chồng');
Insert Into thannhan Values ('NV003', N'Lê Thị Hồng',      N'Nữ',  To_date('22/11/1984','DD/MM/YYYY'), N'Vợ');
Insert Into thannhan Values ('NV003', N'Lê Văn Tú',        N'Nam', To_date('10/04/2010','DD/MM/YYYY'), N'Con');
Insert Into thannhan Values ('NV003', N'Lê Thị Liên',      N'Nữ',  To_date('14/08/2012','DD/MM/YYYY'), N'Con');
Insert Into thannhan Values ('NV004', N'Phạm Văn Đông',    N'Nam', To_date('30/07/1983','DD/MM/YYYY'), N'Chồng');
Insert Into thannhan Values ('NV005', N'Hoàng Thị Yến',    N'Nữ',  To_date('14/02/1985','DD/MM/YYYY'), N'Vợ');
Insert Into thannhan Values ('NV007', N'Vũ Thị Ngân',      N'Nữ',  To_date('25/08/1981','DD/MM/YYYY'), N'Vợ');
Insert Into thannhan Values ('NV007', N'Vũ Minh Khoa',     N'Nam', To_date('03/01/2008','DD/MM/YYYY'), N'Con');
Insert Into thannhan Values ('NV009', N'Đỗ Thị Hằng',      N'Nữ',  To_date('16/05/1988','DD/MM/YYYY'), N'Vợ');
Insert Into thannhan Values ('NV009', N'Đỗ Văn Phong',     N'Nam', To_date('22/03/2015','DD/MM/YYYY'), N'Con');
Insert Into thannhan Values ('NV011', N'Trịnh Thị Bích',   N'Nữ',  To_date('19/09/1986','DD/MM/YYYY'), N'Vợ');
Insert Into thannhan Values ('NV011', N'Trịnh Văn An',     N'Nam', To_date('07/07/2012','DD/MM/YYYY'), N'Con');
Insert Into thannhan Values ('NV012', N'Lý Văn Hùng',      N'Nam', To_date('28/04/1985','DD/MM/YYYY'), N'Chồng');
Insert Into thannhan Values ('NV014', N'Cao Văn Minh',     N'Nam', To_date('11/10/1991','DD/MM/YYYY'), N'Chồng');
Insert Into thannhan Values ('NV017', N'Phan Thị Diễm',    N'Nữ',  To_date('02/03/1980','DD/MM/YYYY'), N'Vợ');
Insert Into thannhan Values ('NV017', N'Phan Văn Khang',   N'Nam', To_date('20/11/2006','DD/MM/YYYY'), N'Con');
Insert Into thannhan Values ('NV019', N'Dương Thị Sen',    N'Nữ',  To_date('08/06/1985','DD/MM/YYYY'), N'Vợ');

Commit;

Select 'PHONGBAN'    As bang, Count(*) As so_ban_ghi From phongban    Union All
Select 'NHANVIEN',            Count(*)               From nhanvien    Union All
Select 'DIADIEM_PHG',         Count(*)               From diadiem_phg Union All
Select 'DEAN',                Count(*)               From dean        Union All
Select 'PHANCONG',            Count(*)               From phancong    Union All
Select 'THANNHAN',            Count(*)               From thannhan;