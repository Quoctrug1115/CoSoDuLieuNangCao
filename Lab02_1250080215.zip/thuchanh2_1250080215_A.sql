Create Table dmkhoa (
    makhoa   Char(2)        Constraint pk_dmkhoa Primary Key,
    tenkhoa  Nvarchar2(30)
);

-- ----------------------------------------------------------
-- Bảng dmmh - Danh mục môn học
-- ----------------------------------------------------------
Create Table dmmh (
    mamh    Char(2)        Constraint pk_dmmh Primary Key,
    tenmh   Nvarchar2(35),
    sotiet  Number(3)
);

-- ----------------------------------------------------------
-- Bảng dmsv - Danh mục sinh viên
-- ----------------------------------------------------------
Create Table dmsv (
    masv      Char(3)        Constraint pk_dmsv Primary Key,
    hosv      Nvarchar2(30),
    tensv     Nvarchar2(10),
    phai      Nvarchar2(3),
    ngaysinh  Date,
    noisinh   Nvarchar2(25),
    makh      Char(2)        Constraint fk_dmsv_khoa References dmkhoa(makhoa),
    hocbong   Number(10,0)
);

-- ----------------------------------------------------------
-- Bảng ketqua - Kết quả (composite PK + 2 FK)
-- ----------------------------------------------------------
Create Table ketqua (
    masv   Char(3)   Constraint fk_kq_sv References dmsv(masv),
    mamh   Char(2)   Constraint fk_kq_mh References dmmh(mamh),
    diem   Number(4,2),
    Constraint pk_ketqua Primary Key (masv, mamh)
);

-- ----------------------------------------------------------
-- Insert dmkhoa (5 khoa)
-- ----------------------------------------------------------
Insert Into dmkhoa Values ('TI', N'Công nghệ thông tin');
Insert Into dmkhoa Values ('KT', N'Kinh tế');
Insert Into dmkhoa Values ('XD', N'Xây dựng');
Insert Into dmkhoa Values ('CK', N'Cơ khí');
Insert Into dmkhoa Values ('HH', N'Hóa học');

-- ----------------------------------------------------------
-- Insert dmmh (5 môn học)
-- ----------------------------------------------------------
Insert Into dmmh Values ('01', N'Cơ sở dữ liệu',     45);
Insert Into dmmh Values ('02', N'Lập trình Java',     60);
Insert Into dmmh Values ('03', N'Mạng máy tính',      45);
Insert Into dmmh Values ('04', N'Toán rời rạc',       30);
Insert Into dmmh Values ('05', N'Kinh tế vi mô',      30);

-- ----------------------------------------------------------
-- Insert dmsv (20 sinh viên)
-- ----------------------------------------------------------
Insert Into dmsv Values ('S01', N'Nguyễn Văn',  N'An',     N'Nam', To_date('15/03/2002','DD/MM/YYYY'), N'Hà Nội',     'TI',  800000);
Insert Into dmsv Values ('S02', N'Trần Thị',    N'Bình',   N'Nữ',  To_date('20/07/2001','DD/MM/YYYY'), N'TP.HCM',     'TI', 1200000);
Insert Into dmsv Values ('S03', N'Lê Hoàng',    N'Cường',  N'Nam', To_date('05/11/2002','DD/MM/YYYY'), N'Đà Nẵng',    'KT',       0);
Insert Into dmsv Values ('S04', N'Phạm Thị',    N'Dung',   N'Nữ',  To_date('12/01/2003','DD/MM/YYYY'), N'Cần Thơ',    'KT',  900000);
Insert Into dmsv Values ('S05', N'Hoàng Văn',   N'Em',     N'Nam', To_date('08/09/2002','DD/MM/YYYY'), N'Huế',        'XD',       0);
Insert Into dmsv Values ('S06', N'Đặng Thị',    N'Phương', N'Nữ',  To_date('22/04/2001','DD/MM/YYYY'), N'Hải Phòng',  'TI', 1500000);
Insert Into dmsv Values ('S07', N'Vũ Minh',     N'Quân',   N'Nam', To_date('17/06/2002','DD/MM/YYYY'), N'Hà Nội',     'CK',  800000);
Insert Into dmsv Values ('S08', N'Bùi Thị',     N'Hoa',    N'Nữ',  To_date('30/10/2003','DD/MM/YYYY'), N'Nam Định',   'TI',       0);
Insert Into dmsv Values ('S09', N'Đỗ Văn',      N'Khôi',   N'Nam', To_date('14/02/2002','DD/MM/YYYY'), N'Nghệ An',    'KT', 1000000);
Insert Into dmsv Values ('S10', N'Ngô Thị',     N'Lan',    N'Nữ',  To_date('03/08/2001','DD/MM/YYYY'), N'Bình Dương', 'HH', 1200000);
Insert Into dmsv Values ('S11', N'Trịnh Văn',   N'Minh',   N'Nam', To_date('19/05/2002','DD/MM/YYYY'), N'Hà Tĩnh',    'TI',       0);
Insert Into dmsv Values ('S12', N'Lý Thị',      N'Ngọc',   N'Nữ',  To_date('25/12/2002','DD/MM/YYYY'), N'Tiền Giang', 'KT',  800000);
Insert Into dmsv Values ('S13', N'Mai Công',     N'Oanh',   N'Nam', To_date('11/07/2003','DD/MM/YYYY'), N'Đồng Nai',   'XD',       0);
Insert Into dmsv Values ('S14', N'Cao Thị',     N'Phúc',   N'Nữ',  To_date('06/03/2001','DD/MM/YYYY'), N'Khánh Hòa',  'CK', 1000000);
Insert Into dmsv Values ('S15', N'Đinh Văn',    N'Quý',    N'Nam', To_date('28/09/2002','DD/MM/YYYY'), N'Bắc Ninh',   'TI', 1500000);
Insert Into dmsv Values ('S16', N'Hồ Thị',      N'Ry',     N'Nữ',  To_date('16/01/2003','DD/MM/YYYY'), N'Gia Lai',    'HH',       0);
Insert Into dmsv Values ('S17', N'Phan Văn',    N'Sơn',    N'Nam', To_date('09/11/2001','DD/MM/YYYY'), N'Quảng Nam',  'KT',  900000);
Insert Into dmsv Values ('S18', N'Tô Thị',      N'Thanh',  N'Nữ',  To_date('23/06/2002','DD/MM/YYYY'), N'Long An',    'XD', 1200000);
Insert Into dmsv Values ('S19', N'Dương Văn',   N'Tuấn',   N'Nam', To_date('01/04/2003','DD/MM/YYYY'), N'Vĩnh Long',  'CK',  800000);
Insert Into dmsv Values ('S20', N'Chu Thị',     N'Uyên',   N'Nữ',  To_date('18/08/2002','DD/MM/YYYY'), N'Hà Nội',     'TI', 1000000);

-- ----------------------------------------------------------
-- Insert ketqua (20 bản ghi)
-- ----------------------------------------------------------
Insert Into ketqua Values ('S01', '01', 8.5);
Insert Into ketqua Values ('S01', '02', 7.0);
Insert Into ketqua Values ('S02', '01', 9.0);
Insert Into ketqua Values ('S02', '03', 6.5);
Insert Into ketqua Values ('S03', '05', 7.5);
Insert Into ketqua Values ('S04', '04', 8.0);
Insert Into ketqua Values ('S04', '05', 6.0);
Insert Into ketqua Values ('S05', '03', 5.5);
Insert Into ketqua Values ('S06', '01', 9.5);
Insert Into ketqua Values ('S06', '02', 8.0);
Insert Into ketqua Values ('S07', '03', 7.0);
Insert Into ketqua Values ('S08', '01', 6.5);
Insert Into ketqua Values ('S09', '04', 8.5);
Insert Into ketqua Values ('S10', '05', 7.5);
Insert Into ketqua Values ('S11', '02', 9.0);
Insert Into ketqua Values ('S12', '05', 5.0);
Insert Into ketqua Values ('S13', '03', 7.0);
Insert Into ketqua Values ('S14', '04', 8.0);
Insert Into ketqua Values ('S15', '01', 9.5);
Insert Into ketqua Values ('S20', '02', 8.5);

Commit;


Select Count(*) As tong_sv      From dmsv;
Select Count(*) As tong_ketqua  From ketqua;








