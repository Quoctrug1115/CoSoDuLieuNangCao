-- 1. Tạo bảng regions
Create Table regions (
    region_id Number Constraint reg_id_pk Primary Key,
    region_name Varchar2(25)
);

-- 2. Tạo bảng countries
Create Table countries (
    country_id Char(2) Constraint country_id_pk Primary Key,
    country_name Varchar2(40),
    region_id Number Constraint countr_reg_fk References regions(region_id)
);

-- 3. Tạo bảng locations
Create Table locations (
    location_id Number(4) Constraint loc_id_pk Primary Key,
    street_address Varchar2(40),
    city Varchar2(30) Not Null,
    state_province Varchar2(25),
    postal_code Varchar2(12),
    country_id Char(2) Constraint loc_c_id_fk References countries(country_id)
);

-- 4. Tạo bảng jobs
Create Table jobs (
    job_id Varchar2(10) Constraint job_id_pk Primary Key,
    job_title Varchar2(35) Not Null,
    min_salary Number(8),
    max_salary Number(8)
);

-- 5. Tạo bảng departments
Create Table departments (
    department_id Number(4) Constraint dept_id_pk Primary Key,
    department_name Varchar2(30) Not Null,
    manager_id Number(6),
    location_id Number(4) Constraint dept_loc_fk References locations(location_id)
);

-- 6. Tạo bảng employees
Create Table employees (
    employee_id Number(6) Constraint emp_emp_id_pk Primary Key,
    last_name Varchar2(25) Not Null,
    first_name Varchar2(20),
    email Varchar2(25) Not Null Unique,
    hire_date Date Not Null,
    job_id Varchar2(10) Not Null Constraint emp_job_fk References jobs(job_id),
    salary Number(8,2),
    commission_pct Number(2,2),
    manager_id Number(6) Constraint emp_manager_fk References employees(employee_id),
    department_id Number(4) Constraint emp_dept_fk References departments(department_id)
);

-- Cập nhật khóa ngoại manager_id cho departments
Alter Table departments 
Add Constraint dept_mgr_fk Foreign Key (manager_id) References employees (employee_id);

-- 7. Tạo bảng job_history
Create Table job_history (
    employee_id Number(6) Constraint jhist_emp_fk References employees(employee_id),
    start_date Date Not Null,
    end_date Date Not Null,
    job_id Varchar2(10) Not Null Constraint jhist_job_fk References jobs(job_id),
    department_id Number(4) Constraint jhist_dept_fk References departments(department_id),
    Constraint jhist_emp_id_st_date_pk Primary Key (employee_id, start_date)
);








-- Dữ liệu mẫu bảng regions
Insert Into regions (region_id, region_name) Values (1, 'Europe');
Insert Into regions (region_id, region_name) Values (2, 'Americas');

-- Dữ liệu mẫu bảng countries
Insert Into countries (country_id, country_name, region_id) Values ('UK', 'United Kingdom', 1);
Insert Into countries (country_id, country_name, region_id) Values ('US', 'United States of America', 2);

-- Dữ liệu mẫu bảng locations
Insert Into locations (location_id, street_address, city, state_province, postal_code, country_id) 
Values (1000, '1297 Via Cola di Rie', 'Rome', Null, '0989', 'UK');
Insert Into locations (location_id, street_address, city, state_province, postal_code, country_id) 
Values (2000, '2004 Charade Rd', 'Seattle', 'Washington', '98199', 'US');

-- Dữ liệu mẫu bảng jobs
Insert Into jobs (job_id, job_title, min_salary, max_salary) Values ('AD_PRES', 'President', 20000, 40000);
Insert Into jobs (job_id, job_title, min_salary, max_salary) Values ('IT_PROG', 'Programmer', 4000, 10000);
Insert Into jobs (job_id, job_title, min_salary, max_salary) Values ('SA_REP', 'Sales Representative', 6000, 12000);

-- Dữ liệu mẫu bảng departments
Insert Into departments (department_id, department_name, manager_id, location_id) Values (10, 'Administration', Null, 2000);
Insert Into departments (department_id, department_name, manager_id, location_id) Values (20, 'IT', Null, 1000);
Insert Into departments (department_id, department_name, manager_id, location_id) Values (30, 'Sales', Null, 2000);

-- Dữ liệu mẫu bảng employees
Insert Into employees (employee_id, last_name, first_name, email, hire_date, job_id, salary, commission_pct, manager_id, department_id) 
Values (100, 'King', 'Steven', 'SKING', To_date('17-06-2003', 'DD-MM-YYYY'), 'AD_PRES', 24000, Null, Null, 10);

Insert Into employees (employee_id, last_name, first_name, email, hire_date, job_id, salary, commission_pct, manager_id, department_id) 
Values (101, 'Kochhar', 'Neena', 'NKOCHHAR', To_date('21-09-2005', 'DD-MM-YYYY'), 'AD_PRES', 17000, Null, 100, 10);

Insert Into employees (employee_id, last_name, first_name, email, hire_date, job_id, salary, commission_pct, manager_id, department_id) 
Values (102, 'De Haan', 'Lex', 'LDEHAAN', To_date('13-01-2001', 'DD-MM-YYYY'), 'IT_PROG', 17000, Null, 100, 20);

Insert Into employees (employee_id, last_name, first_name, email, hire_date, job_id, salary, commission_pct, manager_id, department_id) 
Values (103, 'Hunold', 'Alexander', 'AHUNOLD', To_date('03-01-2006', 'DD-MM-YYYY'), 'IT_PROG', 9000, Null, 102, 20);

Insert Into employees (employee_id, last_name, first_name, email, hire_date, job_id, salary, commission_pct, manager_id, department_id) 
Values (104, 'Ernst', 'Bruce', 'BERNST', To_date('21-05-2007', 'DD-MM-YYYY'), 'IT_PROG', 6000, Null, 103, 20);

Insert Into employees (employee_id, last_name, first_name, email, hire_date, job_id, salary, commission_pct, manager_id, department_id) 
Values (105, 'Tucker', 'Peter', 'PTUCKER', To_date('30-01-2005', 'DD-MM-YYYY'), 'SA_REP', 10000, 0.3, 100, 30);

Insert Into employees (employee_id, last_name, first_name, email, hire_date, job_id, salary, commission_pct, manager_id, department_id) 
Values (106, 'Bernstein', 'David', 'DBERNSTE', To_date('24-03-2005', 'DD-MM-YYYY'), 'SA_REP', 9500, 0.25, 105, 30);

Insert Into employees (employee_id, last_name, first_name, email, hire_date, job_id, salary, commission_pct, manager_id, department_id) 
Values (107, 'Hall', 'Peter', 'PHALL', To_date('20-08-2005', 'DD-MM-YYYY'), 'SA_REP', 9000, 0.25, 105, 30);

-- Cập nhật lại Quản lý cho phòng ban 
Update departments Set manager_id = 100 Where department_id = 10;
Update departments Set manager_id = 103 Where department_id = 20;
Update departments Set manager_id = 105 Where department_id = 30;

Commit;





-- ------------------------------------------------------------
-- CÂU 1: Nhân viên có lương > 12000$
--
Select last_name,
       salary
  From employees
 Where salary > 12000;

-- ------------------------------------------------------------
-- CÂU 2: Nhân viên có lương < 5000$ hoặc > 12000$
-- ------------------------------------------------------------
Select last_name,
       salary
  From employees
 Where salary < 5000
    Or salary > 12000;

-- ------------------------------------------------------------
-- CÂU 3: Nhân viên thuê từ 20/02/1998 đến 01/05/1998, tăng dần theo hire_date
-- ------------------------------------------------------------
-- Luôn chỉ định format mask tránh phụ thuộc NLS_DATE_FORMAT server.
Select last_name,
       job_id,
       hire_date
  From employees
 Where hire_date Between To_date('20/02/1998', 'DD/MM/YYYY')
                     And To_date('01/05/1998', 'DD/MM/YYYY')
 Order By hire_date Asc;

-- ------------------------------------------------------------
-- CÂU 4: Nhân viên phòng 20 và 50, sắp xếp tên alphabet
-- ------------------------------------------------------------
Select last_name,
       department_id
  From employees
 Where department_id In (20, 50)
 Order By last_name Asc;

-- ------------------------------------------------------------
-- CÂU 5: Nhân viên được thuê năm 1994
-- ------------------------------------------------------------
Select last_name,
       hire_date
  From employees
 Where To_char(hire_date, 'YYYY') = '1994';

-- ------------------------------------------------------------
-- CÂU 6: Nhân viên không có người quản lý
-- ------------------------------------------------------------
-- NULL không thể dùng = NULL, bắt buộc IS NULL.
Select last_name,
       job_id
  From employees
 Where manager_id Is Null;

-- ------------------------------------------------------------
-- CÂU 7: Nhân viên được hưởng hoa hồng, giảm dần theo lương rồi hoa hồng
-- ------------------------------------------------------------
Select last_name,
       salary,
       commission_pct
  From employees
 Where commission_pct Is Not Null
 Order By salary Desc,
          commission_pct Desc;

-- ------------------------------------------------------------
-- CÂU 8: Nhân viên có ký tự thứ 3 trong tên là 'a'
-- ------------------------------------------------------------
-- "__a%" : _ = đúng 1 ký tự bất kỳ, % = chuỗi bất kỳ.
Select last_name
  From employees
 Where last_name Like '__a%';

-- ------------------------------------------------------------
-- CÂU 9: Nhân viên có tên chứa cả 'a' VÀ 'e'
-- ------------------------------------------------------------
Select last_name
  From employees
 Where last_name Like '%a%'
   And last_name Like '%e%';

-- ------------------------------------------------------------
-- CÂU 10: Nhân viên làm SA_REP / ST_CLERK, lương không phải 2500, 3500, 7000
-- ------------------------------------------------------------
-- NOT IN an toàn vì giá trị hardcode không chứa NULL.
Select last_name,
       job_id,
       salary
  From employees
 Where job_id In ('SA_REP', 'ST_CLERK')
   And salary Not In (2500, 3500, 7000);

-- ------------------------------------------------------------
-- CÂU 11: Lương tăng 15%, làm tròn hàng đơn vị, cột "New Salary"
-- ------------------------------------------------------------
Select employee_id,
       last_name,
       salary,
       Round(salary * 1.15, 0) As "New Salary"
  From employees;

-- ------------------------------------------------------------
-- CÂU 12: Nhân viên tên bắt đầu J/A/L/M, hiển thị Initcap + độ dài
-- ------------------------------------------------------------
-- INITCAP: chữ đầu HOA, còn lại thường.
Select Initcap(last_name) As ten_nhan_vien,
       Length(last_name)  As chieu_dai_ten
  From employees
 Where Substr(last_name, 1, 1) In ('J', 'A', 'L', 'M')
 Order By last_name Asc;

-- ------------------------------------------------------------
-- CÂU 13: Số tháng làm việc từ ngày thuê đến nay, tăng dần
-- ------------------------------------------------------------
-- TRUNC(...,0) lấy phần nguyên số tháng.
Select last_name,
       hire_date,
       Trunc(Months_between(Sysdate, hire_date), 0) As so_thang_lam_viec
  From employees
 Order By so_thang_lam_viec Asc;

-- ------------------------------------------------------------
-- CÂU 14: "<last_name> earns <salary> monthly but wants <3*salary>"
-- ------------------------------------------------------------
Select last_name
       || ' earns '
       || To_char(salary)
       || ' monthly but wants '
       || To_char(salary * 3)  As "Dream Salaries"
  From employees;

-- ------------------------------------------------------------
-- CÂU 15: Tên NV + hoa hồng, nếu không có hiển thị 'No commission'
-- ------------------------------------------------------------
Select last_name,
       Nvl(To_char(commission_pct), 'No commission') As commission
  From employees;

-- ------------------------------------------------------------
-- CÂU 16: Phân loại GRADE theo job_id bằng DECODE
-- ------------------------------------------------------------
Select job_id,
       Decode(job_id,
              'AD_PRES',  'A',
              'ST_MAN',   'B',
              'IT_PROG',  'C',
              'SA_REP',   'D',
              'ST_CLERK', 'E',
                          '0') As grade
  From employees;

-- ------------------------------------------------------------
-- CÂU 17: Nhân viên ở thành phố Toronto
-- ------------------------------------------------------------
Select e.last_name,
       e.department_id,
       d.department_name
  From employees   e
  Join departments d On e.department_id = d.department_id
  Join locations   l On d.location_id   = l.location_id
 Where l.city = 'Toronto';

-- ------------------------------------------------------------
-- CÂU 18: Self Join - NV + tên người quản lý
-- ------------------------------------------------------------
-- e = nhân viên, m = manager. INNER JOIN loại bỏ NV không có QL.
Select e.employee_id As ma_nhan_vien,
       e.last_name   As ten_nhan_vien,
       m.employee_id As ma_quan_ly,
       m.last_name   As ten_quan_ly
  From employees e
  Join employees m On e.manager_id = m.employee_id;

-- ------------------------------------------------------------
-- CÂU 19: Nhân viên làm việc cùng phòng (từng cặp, không trùng)
-- ------------------------------------------------------------
-- e1.employee_id < e2.employee_id tránh kết quả lặp đôi A-B / B-A.
Select e1.employee_id  As ma_nv1,
       e1.last_name    As ten_nv1,
       e2.employee_id  As ma_nv2,
       e2.last_name    As ten_nv2,
       e1.department_id
  From employees e1
  Join employees e2 On  e1.department_id = e2.department_id
                    And e1.employee_id   < e2.employee_id
 Order By e1.department_id, e1.employee_id;

-- ------------------------------------------------------------
-- CÂU 20: Nhân viên thuê SAU Davies
-- ------------------------------------------------------------
Select last_name,
       hire_date
  From employees
 Where hire_date > (Select hire_date
                      From employees
                     Where last_name = 'Davies');

-- ------------------------------------------------------------
-- CÂU 21: Nhân viên thuê TRƯỚC người quản lý của họ
-- ------------------------------------------------------------
Select e.last_name As ten_nhan_vien,
       e.hire_date As ngay_thue_nv,
       m.last_name As ten_quan_ly,
       m.hire_date As ngay_thue_ql
  From employees e
  Join employees m On e.manager_id = m.employee_id
 Where e.hire_date < m.hire_date;

-- ------------------------------------------------------------
-- CÂU 22: Min/Max/Avg/Sum lương theo từng job_id
-- ------------------------------------------------------------
Select job_id,
       Min(salary)           As luong_thap_nhat,
       Max(salary)           As luong_cao_nhat,
       Round(Avg(salary), 2) As luong_trung_binh,
       Sum(salary)           As tong_luong
  From employees
 Group By job_id
 Order By job_id;

-- ------------------------------------------------------------
-- CÂU 23a: Mã phòng, tên phòng, số nhân viên từng phòng
-- ------------------------------------------------------------
-- LEFT JOIN giữ lại phòng có 0 nhân viên.
Select d.department_id,
       d.department_name,
       Count(e.employee_id) As so_nhan_vien
  From departments d
  Left Join employees e On d.department_id = e.department_id
 Group By d.department_id, d.department_name
 Order By d.department_id;

-- ------------------------------------------------------------
-- CÂU 23b: Tổng NV + số NV được thuê từng năm 1995-1998
-- ------------------------------------------------------------
-- Conditional aggregation: scan bảng 1 lần thay vì GROUP BY 4 lần.
Select Count(*)                                                              As tong_nhan_vien,
       Sum(Case When To_char(hire_date,'YYYY')='1995' Then 1 Else 0 End)     As nam_1995,
       Sum(Case When To_char(hire_date,'YYYY')='1996' Then 1 Else 0 End)     As nam_1996,
       Sum(Case When To_char(hire_date,'YYYY')='1997' Then 1 Else 0 End)     As nam_1997,
       Sum(Case When To_char(hire_date,'YYYY')='1998' Then 1 Else 0 End)     As nam_1998
  From employees;

-- ------------------------------------------------------------
-- CÂU 25: Tên, ngày thuê NV làm cùng phòng với 'Zlotkey'
-- ------------------------------------------------------------
Select last_name,
       hire_date
  From employees
 Where department_id = (Select department_id
                          From employees
                         Where last_name = 'Zlotkey')
   And last_name <> 'Zlotkey';

-- ------------------------------------------------------------
-- CÂU 26: NV làm ở phòng có location_id = 1700
-- ------------------------------------------------------------
Select last_name,
       department_id,
       job_id
  From employees
 Where department_id In (Select department_id
                           From departments
                          Where location_id = 1700);

-- ------------------------------------------------------------
-- CÂU 27: NV có người quản lý tên 'King'
-- ------------------------------------------------------------
Select last_name,
       salary,
       job_id
  From employees
 Where manager_id In (Select employee_id
                        From employees
                       Where last_name = 'King');

-- ------------------------------------------------------------
-- CÂU 28: NV lương > trung bình VÀ làm cùng phòng NV tên kết thúc 'n'
-- ------------------------------------------------------------
Select last_name,
       salary,
       department_id
  From employees
 Where salary > (Select Avg(salary) From employees)
   And department_id In (Select department_id
                           From employees
                          Where last_name Like '%n');

-- ------------------------------------------------------------
-- CÂU 29: Phòng ban có ít hơn 3 nhân viên
-- ------------------------------------------------------------
Select d.department_id,
       d.department_name,
       Count(e.employee_id) As so_nhan_vien
  From departments d
  Left Join employees e On d.department_id = e.department_id
 Group By d.department_id, d.department_name
Having Count(e.employee_id) < 3
 Order By so_nhan_vien Desc;

-- ------------------------------------------------------------
-- CÂU 30: Phòng đông nhân viên nhất và ít nhân viên nhất
-- ------------------------------------------------------------
Select d.department_id,
       d.department_name,
       Count(e.employee_id) As so_nhan_vien,
       'Dong nhat'          As loai
  From departments d
  Join employees   e On d.department_id = e.department_id
 Group By d.department_id, d.department_name
Having Count(e.employee_id) = (
           Select Max(cnt) From (
               Select Count(employee_id) As cnt
                 From employees
                Where department_id Is Not Null
                Group By department_id))
 Union All
Select d.department_id,
       d.department_name,
       Count(e.employee_id) As so_nhan_vien,
       'It nhat'            As loai
  From departments d
  Join employees   e On d.department_id = e.department_id
 Group By d.department_id, d.department_name
Having Count(e.employee_id) = (
           Select Min(cnt) From (
               Select Count(employee_id) As cnt
                 From employees
                Where department_id Is Not Null
                Group By department_id));

-- ------------------------------------------------------------
-- CÂU 31: NV thuê vào thứ có số lượng thuê đông nhất
-- ------------------------------------------------------------
-- TRIM loại bỏ khoảng trắng padding của TO_CHAR('Day').
-- FETCH FIRST 1 ROWS ONLY (Oracle 12c+) lấy thứ top 1.
Select last_name,
       hire_date,
       Trim(To_char(hire_date, 'Day')) As thu_trong_tuan
  From employees
 Where Trim(To_char(hire_date, 'Day')) = (
           Select Trim(To_char(hire_date, 'Day'))
             From employees
            Group By Trim(To_char(hire_date, 'Day'))
            Order By Count(*) Desc
            Fetch First 1 Rows Only)
 Order By hire_date;

-- ------------------------------------------------------------
-- CÂU 32: 3 nhân viên có lương cao nhất
-- ------------------------------------------------------------
-- Inline View bắt buộc: sort TRONG subquery trước, ROWNUM áp ngoài sau.
Select last_name,
       salary,
       job_id
  From (Select last_name, salary, job_id
          From employees
         Order By salary Desc)
 Where Rownum <= 3;

-- ------------------------------------------------------------
-- CÂU 33: NV làm việc ở tiểu bang 'California'
-- ------------------------------------------------------------
Select e.last_name,
       e.job_id,
       d.department_name,
       l.city,
       l.state_province
  From employees   e
  Join departments d On e.department_id = d.department_id
  Join locations   l On d.location_id   = l.location_id
 Where l.state_province = 'California';

-- ------------------------------------------------------------
-- CÂU 34: Cập nhật tên NV mã = 3 thành 'Drexler'
-- ------------------------------------------------------------
Update employees
   Set last_name = 'Drexler'
 Where employee_id = 3;

Commit;

Select employee_id, last_name From employees Where employee_id = 3;

-- ------------------------------------------------------------
-- CÂU 35: NV có lương thấp hơn lương trung bình của phòng mình
-- ------------------------------------------------------------
-- Correlated subquery: e2.department_id = e1.department_id tham chiếu ngoài,
-- chạy lại cho từng hàng → trung bình đúng theo từng phòng.
Select e1.last_name,
       e1.salary,
       e1.department_id
  From employees e1
 Where e1.salary < (Select Avg(e2.salary)
                      From employees e2
                     Where e2.department_id = e1.department_id)
 Order By e1.department_id, e1.salary;

-- ------------------------------------------------------------
-- CÂU 36: Tăng thêm 100$ cho NV có lương < 900$
-- ------------------------------------------------------------
Select employee_id, last_name, salary
  From employees
 Where salary < 900;

Update employees
   Set salary = salary + 100
 Where salary < 900;

Commit;

-- ------------------------------------------------------------
-- CÂU 37: Xóa phòng ban 500
-- ------------------------------------------------------------
-- Xử lý FK: NULL department_id của NV phòng 500 trước khi xóa phòng.
Select Count(*) As so_nv_phong_500 From employees Where department_id = 500;

Update employees
   Set department_id = Null
 Where department_id = 500;

Delete From departments Where department_id = 500;

Commit;

-- ------------------------------------------------------------
-- CÂU 38: Xóa các phòng ban chưa có nhân viên
-- ------------------------------------------------------------
-- NOT EXISTS an toàn hơn NOT IN khi subquery có thể có NULL.
-- (NOT IN với NULL trong tập con → luôn trả 0 hàng - bẫy phổ biến)
Delete From departments d
 Where Not Exists (
           Select 1
             From employees e
            Where e.department_id = d.department_id);

Commit;

Select department_id, department_name From departments Order By department_id;


