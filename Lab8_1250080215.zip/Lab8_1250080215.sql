CREATE TABLE HangSX (
    MaHangSX VARCHAR2(10) CONSTRAINT pk_hangsx PRIMARY KEY,
    TenHang VARCHAR2(30) NOT NULL,
    DiaChi VARCHAR2(50),
    SoDT VARCHAR2(15),
    Email VARCHAR2(50)
);
CREATE TABLE SanPham (
    MaSP VARCHAR2(10) CONSTRAINT pk_sanpham PRIMARY KEY,
    MaHangSX VARCHAR2(10) REFERENCES HangSX(MaHangSX),
    TenSP VARCHAR2(50) NOT NULL,
    SoLuong NUMBER(10),
    MauSac VARCHAR2(20),
    GiaBan NUMBER(15,2),
    DonViTinh VARCHAR2(15),
    MoTa CLOB
);
CREATE TABLE NhanVien (
    MaNV VARCHAR2(10) CONSTRAINT pk_nhanvien PRIMARY KEY,
    TenNV VARCHAR2(50) NOT NULL,
    GioiTinh VARCHAR2(10),
    DiaChi VARCHAR2(100),
    SoDT VARCHAR2(15),
    Email VARCHAR2(50),
    TenPhong VARCHAR2(30)
);
CREATE TABLE PNhap (
    SoHDN VARCHAR2(10) CONSTRAINT pk_pnhap PRIMARY KEY,
    NgayNhap DATE,
    MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV)
);
CREATE TABLE Nhap (
    SoHDN VARCHAR2(10) REFERENCES PNhap(SoHDN),
    MaSP VARCHAR2(10) REFERENCES SanPham(MaSP),
    SoLuongN NUMBER(10),
    DonGiaN NUMBER(15,2),
    CONSTRAINT pk_nhap PRIMARY KEY (SoHDN, MaSP)
);
CREATE TABLE PXuat (
    SoHDX VARCHAR2(10) CONSTRAINT pk_pxuat PRIMARY KEY,
    NgayXuat DATE,
    MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV)
);
CREATE TABLE Xuat (
    SoHDX VARCHAR2(10) REFERENCES PXuat(SoHDX),
    MaSP VARCHAR2(10) REFERENCES SanPham(MaSP),
    SoLuongX NUMBER(10),
    CONSTRAINT pk_xuat PRIMARY KEY (SoHDX, MaSP)
);



CREATE OR REPLACE PROCEDURE sp_NhapHangSX (
    p_MaHangSX IN VARCHAR2, p_TenHang IN VARCHAR2, p_DiaChi IN VARCHAR2, 
    p_SoDT IN VARCHAR2, p_Email IN VARCHAR2
) AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count FROM HangSX WHERE TenHang = p_TenHang;
    IF v_count > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Lỗi: Tên hãng sản xuất đã tồn tại!');
    ELSE
        INSERT INTO HangSX (MaHangSX, TenHang, DiaChi, SoDT, Email) 
        VALUES (p_MaHangSX, p_TenHang, p_DiaChi, p_SoDT, p_Email);
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Thêm mới hãng sản xuất thành công.');
    END IF;
END;
/


CREATE OR REPLACE PROCEDURE sp_NhapSP (
    p_MaSP IN VARCHAR2, p_TenHang IN VARCHAR2, p_TenSP IN VARCHAR2, 
    p_SoLuong IN NUMBER, p_MauSac IN VARCHAR2, p_GiaBan IN NUMBER, 
    p_DonViTinh IN VARCHAR2, p_MoTa IN CLOB
) AS
    v_MaHangSX HangSX.MaHangSX%TYPE;
    v_count_sp NUMBER;
BEGIN
    -- Tìm mã hãng theo tên
    BEGIN
        SELECT MaHangSX INTO v_MaHangSX FROM HangSX WHERE TenHang = p_TenHang;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Lỗi: Tên hãng không tồn tại trong hệ thống!');
            RETURN;
    END;

    -- Kiểm tra tồn tại sản phẩm
    SELECT COUNT(*) INTO v_count_sp FROM SanPham WHERE MaSP = p_MaSP;
    
    IF v_count_sp > 0 THEN
        UPDATE SanPham 
        SET MaHangSX = v_MaHangSX, TenSP = p_TenSP, SoLuong = p_SoLuong, 
            MauSac = p_MauSac, GiaBan = p_GiaBan, DonViTinh = p_DonViTinh, MoTa = p_MoTa
        WHERE MaSP = p_MaSP;
        DBMS_OUTPUT.PUT_LINE('Cập nhật thông tin sản phẩm thành công.');
    ELSE
        INSERT INTO SanPham (MaSP, MaHangSX, TenSP, SoLuong, MauSac, GiaBan, DonViTinh, MoTa)
        VALUES (p_MaSP, v_MaHangSX, p_TenSP, p_SoLuong, p_MauSac, p_GiaBan, p_DonViTinh, p_MoTa);
        DBMS_OUTPUT.PUT_LINE('Thêm mới sản phẩm thành công.');
    END IF;
    COMMIT;
END;
/


CREATE OR REPLACE PROCEDURE sp_xoaHangSX (p_TenHang IN VARCHAR2) AS
    v_MaHangSX HangSX.MaHangSX%TYPE;
BEGIN
    BEGIN
        SELECT MaHangSX INTO v_MaHangSX FROM HangSX WHERE TenHang = p_TenHang;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Lỗi: Tên hãng không tồn tại!');
            RETURN;
    END;

    -- Cascade delete thủ công: Xóa SanPham trước, HangSX sau
    DELETE FROM SanPham WHERE MaHangSX = v_MaHangSX;
    DELETE FROM HangSX WHERE MaHangSX = v_MaHangSX;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Đã xóa hãng sản xuất và các sản phẩm liên quan.');
END;
/


CREATE OR REPLACE PROCEDURE sp_NhapNhanVien (
    p_MaNV IN VARCHAR2, p_TenNV IN VARCHAR2, p_GioiTinh IN VARCHAR2, 
    p_DiaChi IN VARCHAR2, p_SoDT IN VARCHAR2, p_Email IN VARCHAR2, 
    p_TenPhong IN VARCHAR2, p_Flag IN NUMBER
) AS
BEGIN
    IF p_Flag = 0 THEN
        UPDATE NhanVien 
        SET TenNV = p_TenNV, GioiTinh = p_GioiTinh, DiaChi = p_DiaChi, 
            SoDT = p_SoDT, Email = p_Email, TenPhong = p_TenPhong
        WHERE MaNV = p_MaNV;
        DBMS_OUTPUT.PUT_LINE('Cập nhật nhân viên thành công.');
    ELSE
        INSERT INTO NhanVien (MaNV, TenNV, GioiTinh, DiaChi, SoDT, Email, TenPhong)
        VALUES (p_MaNV, p_TenNV, p_GioiTinh, p_DiaChi, p_SoDT, p_Email, p_TenPhong);
        DBMS_OUTPUT.PUT_LINE('Thêm mới nhân viên thành công.');
    END IF;
    COMMIT;
END;
/


CREATE OR REPLACE PROCEDURE sp_NhapDuLieuNhap (
    p_SoHDN IN VARCHAR2, p_MaSP IN VARCHAR2, p_MaNV IN VARCHAR2, 
    p_NgayNhap IN DATE, p_SoLuongN IN NUMBER, p_DonGiaN IN NUMBER
) AS
    v_check NUMBER;
BEGIN
    -- Validate MaSP
    SELECT COUNT(*) INTO v_check FROM SanPham WHERE MaSP = p_MaSP;
    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Lỗi: Mã sản phẩm không tồn tại!'); RETURN;
    END IF;

    -- Validate MaNV
    SELECT COUNT(*) INTO v_check FROM NhanVien WHERE MaNV = p_MaNV;
    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Lỗi: Mã nhân viên không tồn tại!'); RETURN;
    END IF;

    -- Check PNhap (Hóa đơn)
    SELECT COUNT(*) INTO v_check FROM PNhap WHERE SoHDN = p_SoHDN;
    IF v_check > 0 THEN
        -- Giả định cập nhật số lượng và đơn giá cho chi tiết nhập
        UPDATE Nhap SET SoLuongN = p_SoLuongN, DonGiaN = p_DonGiaN 
        WHERE SoHDN = p_SoHDN AND MaSP = p_MaSP;
        DBMS_OUTPUT.PUT_LINE('Cập nhật chi tiết nhập thành công.');
    ELSE
        INSERT INTO PNhap (SoHDN, NgayNhap, MaNV) VALUES (p_SoHDN, p_NgayNhap, p_MaNV);
        INSERT INTO Nhap (SoHDN, MaSP, SoLuongN, DonGiaN) VALUES (p_SoHDN, p_MaSP, p_SoLuongN, p_DonGiaN);
        DBMS_OUTPUT.PUT_LINE('Thêm mới phiếu nhập và chi tiết thành công.');
    END IF;
    COMMIT;
END;
/


CREATE OR REPLACE PROCEDURE sp_NhapDuLieuXuat (
    p_SoHDX IN VARCHAR2, p_MaSP IN VARCHAR2, p_MaNV IN VARCHAR2, 
    p_NgayXuat IN DATE, p_SoLuongX IN NUMBER
) AS
    v_check NUMBER;
    v_TonKho NUMBER;
BEGIN
    -- Validate MaSP & lấy tồn kho
    BEGIN
        SELECT SoLuong INTO v_TonKho FROM SanPham WHERE MaSP = p_MaSP;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Lỗi: Mã sản phẩm không tồn tại!'); RETURN;
    END;

    -- Validate MaNV
    SELECT COUNT(*) INTO v_check FROM NhanVien WHERE MaNV = p_MaNV;
    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Lỗi: Mã nhân viên không tồn tại!'); RETURN;
    END IF;

    -- Logic tồn kho
    IF p_SoLuongX > v_TonKho THEN
        DBMS_OUTPUT.PUT_LINE('Lỗi: Số lượng xuất vượt quá tồn kho!'); RETURN;
    END IF;

    -- Check PXuat (Hóa đơn)
    SELECT COUNT(*) INTO v_check FROM PXuat WHERE SoHDX = p_SoHDX;
    IF v_check > 0 THEN
        UPDATE Xuat SET SoLuongX = p_SoLuongX WHERE SoHDX = p_SoHDX AND MaSP = p_MaSP;
        DBMS_OUTPUT.PUT_LINE('Cập nhật chi tiết xuất thành công.');
    ELSE
        INSERT INTO PXuat (SoHDX, NgayXuat, MaNV) VALUES (p_SoHDX, p_NgayXuat, p_MaNV);
        INSERT INTO Xuat (SoHDX, MaSP, SoLuongX) VALUES (p_SoHDX, p_MaSP, p_SoLuongX);
        DBMS_OUTPUT.PUT_LINE('Thêm mới phiếu xuất và chi tiết thành công.');
    END IF;
    COMMIT;
END;
/


CREATE OR REPLACE PROCEDURE sp_XoaNhanVien (p_MaNV IN VARCHAR2) AS
    v_check NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_check FROM NhanVien WHERE MaNV = p_MaNV;
    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Lỗi: Nhân viên không tồn tại!'); RETURN;
    END IF;

    -- Xóa liên kết Nhập
    DELETE FROM Nhap WHERE SoHDN IN (SELECT SoHDN FROM PNhap WHERE MaNV = p_MaNV);
    DELETE FROM PNhap WHERE MaNV = p_MaNV;
    -- Xóa liên kết Xuất
    DELETE FROM Xuat WHERE SoHDX IN (SELECT SoHDX FROM PXuat WHERE MaNV = p_MaNV);
    DELETE FROM PXuat WHERE MaNV = p_MaNV;
    -- Xóa bảng chính
    DELETE FROM NhanVien WHERE MaNV = p_MaNV;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Đã xóa nhân viên và toàn bộ phiếu nhập/xuất liên quan.');
END;
/

CREATE OR REPLACE PROCEDURE sp_XoaSanPham (p_MaSP IN VARCHAR2) AS
    v_check NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_check FROM SanPham WHERE MaSP = p_MaSP;
    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Lỗi: Sản phẩm không tồn tại!'); RETURN;
    END IF;

    DELETE FROM Nhap WHERE MaSP = p_MaSP;
    DELETE FROM Xuat WHERE MaSP = p_MaSP;
    DELETE FROM SanPham WHERE MaSP = p_MaSP;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Đã xóa sản phẩm và lịch sử nhập/xuất.');
END;
/



CREATE OR REPLACE PROCEDURE sp_ThemNhanVien_Out (
    p_MaNV IN VARCHAR2, p_TenNV IN VARCHAR2, p_GioiTinh IN VARCHAR2, 
    p_DiaChi IN VARCHAR2, p_SoDT IN VARCHAR2, p_Email IN VARCHAR2, 
    p_TenPhong IN VARCHAR2, p_Flag IN NUMBER, p_KQ OUT NUMBER
) AS
BEGIN
    IF p_GioiTinh NOT IN ('Nam', 'Nu', 'Nữ') THEN
        p_KQ := 1; RETURN;
    END IF;

    IF p_Flag = 0 THEN
        INSERT INTO NhanVien VALUES (p_MaNV, p_TenNV, p_GioiTinh, p_DiaChi, p_SoDT, p_Email, p_TenPhong);
    ELSE
        UPDATE NhanVien SET TenNV = p_TenNV, GioiTinh = p_GioiTinh, DiaChi = p_DiaChi, 
            SoDT = p_SoDT, Email = p_Email, TenPhong = p_TenPhong WHERE MaNV = p_MaNV;
    END IF;
    p_KQ := 0;
    COMMIT;
EXCEPTION WHEN OTHERS THEN p_KQ := SQLCODE; ROLLBACK;
END;
/


CREATE OR REPLACE PROCEDURE sp_ThemMoiSP_Out (
    p_MaSP IN VARCHAR2, p_TenHang IN VARCHAR2, p_TenSP IN VARCHAR2, 
    p_SoLuong IN NUMBER, p_MauSac IN VARCHAR2, p_GiaBan IN NUMBER, 
    p_DonViTinh IN VARCHAR2, p_MoTa IN CLOB, p_Flag IN NUMBER, p_KQ OUT NUMBER
) AS
    v_MaHangSX HangSX.MaHangSX%TYPE;
BEGIN
    BEGIN
        SELECT MaHangSX INTO v_MaHangSX FROM HangSX WHERE TenHang = p_TenHang;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN p_KQ := 1; RETURN;
    END;

    IF p_SoLuong < 0 THEN
        p_KQ := 2; RETURN;
    END IF;

    IF p_Flag = 0 THEN
        INSERT INTO SanPham VALUES (p_MaSP, v_MaHangSX, p_TenSP, p_SoLuong, p_MauSac, p_GiaBan, p_DonViTinh, p_MoTa);
    ELSE
        UPDATE SanPham SET MaHangSX = v_MaHangSX, TenSP = p_TenSP, SoLuong = p_SoLuong, 
            MauSac = p_MauSac, GiaBan = p_GiaBan, DonViTinh = p_DonViTinh, MoTa = p_MoTa
        WHERE MaSP = p_MaSP;
    END IF;
    p_KQ := 0;
    COMMIT;
END;
/


CREATE OR REPLACE PROCEDURE sp_XoaSanPham_Out (p_MaSP IN VARCHAR2, p_KQ OUT NUMBER) AS
    v_check NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_check FROM SanPham WHERE MaSP = p_MaSP;
    IF v_check = 0 THEN
        p_KQ := 1; RETURN;
    END IF;

    DELETE FROM Nhap WHERE MaSP = p_MaSP;
    DELETE FROM Xuat WHERE MaSP = p_MaSP;
    DELETE FROM SanPham WHERE MaSP = p_MaSP;
    p_KQ := 0;
    COMMIT;
END;
/


CREATE OR REPLACE PROCEDURE sp_NhapHangSX_Out (
    p_MaHangSX IN VARCHAR2, p_TenHang IN VARCHAR2, p_DiaChi IN VARCHAR2, 
    p_SoDT IN VARCHAR2, p_Email IN VARCHAR2, p_KQ OUT NUMBER
) AS
    v_check NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_check FROM HangSX WHERE TenHang = p_TenHang;
    IF v_check > 0 THEN
        p_KQ := 1; RETURN;
    END IF;

    INSERT INTO HangSX VALUES (p_MaHangSX, p_TenHang, p_DiaChi, p_SoDT, p_Email);
    p_KQ := 0;
    COMMIT;
END;
/


CREATE OR REPLACE PROCEDURE sp_NhapBangNhap_Out (
    p_SoHDN IN VARCHAR2, p_MaSP IN VARCHAR2, p_MaNV IN VARCHAR2, 
    p_NgayNhap IN DATE, p_SoLuongN IN NUMBER, p_DonGiaN IN NUMBER, p_KQ OUT NUMBER
) AS
    v_check NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_check FROM SanPham WHERE MaSP = p_MaSP;
    IF v_check = 0 THEN p_KQ := 1; RETURN; END IF;

    SELECT COUNT(*) INTO v_check FROM NhanVien WHERE MaNV = p_MaNV;
    IF v_check = 0 THEN p_KQ := 2; RETURN; END IF;

    SELECT COUNT(*) INTO v_check FROM PNhap WHERE SoHDN = p_SoHDN;
    IF v_check > 0 THEN
        UPDATE Nhap SET SoLuongN = p_SoLuongN, DonGiaN = p_DonGiaN 
        WHERE SoHDN = p_SoHDN AND MaSP = p_MaSP;
    ELSE
        INSERT INTO PNhap VALUES (p_SoHDN, p_NgayNhap, p_MaNV);
        INSERT INTO Nhap VALUES (p_SoHDN, p_MaSP, p_SoLuongN, p_DonGiaN);
    END IF;
    p_KQ := 0;
    COMMIT;
END;
/


CREATE OR REPLACE PROCEDURE sp_NhapBangXuat_Out (
    p_SoHDX IN VARCHAR2, p_MaSP IN VARCHAR2, p_MaNV IN VARCHAR2, 
    p_NgayXuat IN DATE, p_SoLuongX IN NUMBER, p_KQ OUT NUMBER
) AS
    v_check NUMBER;
    v_TonKho NUMBER;
BEGIN
    BEGIN
        SELECT SoLuong INTO v_TonKho FROM SanPham WHERE MaSP = p_MaSP;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN p_KQ := 1; RETURN;
    END;

    SELECT COUNT(*) INTO v_check FROM NhanVien WHERE MaNV = p_MaNV;
    IF v_check = 0 THEN p_KQ := 2; RETURN; END IF;

    IF p_SoLuongX > v_TonKho THEN p_KQ := 3; RETURN; END IF;

    SELECT COUNT(*) INTO v_check FROM PXuat WHERE SoHDX = p_SoHDX;
    IF v_check > 0 THEN
        UPDATE Xuat SET SoLuongX = p_SoLuongX WHERE SoHDX = p_SoHDX AND MaSP = p_MaSP;
    ELSE
        INSERT INTO PXuat VALUES (p_SoHDX, p_NgayXuat, p_MaNV);
        INSERT INTO Xuat VALUES (p_SoHDX, p_MaSP, p_SoLuongX);
    END IF;
    p_KQ := 0;
    COMMIT;
END;
/