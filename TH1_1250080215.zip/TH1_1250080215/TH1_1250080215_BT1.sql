create table HANGHANGKHONG (
    MAHANG   varchar2(5) primary key,
    TENHANG  varchar2(100),
    NGTL     date,
    DUONGBAY number
);
create table CHUYENBAY (
    MACB      varchar2(10) primary key,
    MAHANG    varchar2(5),
    XUATPHAT  varchar2(50),
    DIEMDEN   varchar2(50),
    BATDAU    date,
    TGBAY     number,
    constraint FK_CB_HHK foreign key (MAHANG)
        references HANGHANGKHONG(MAHANG)
);
create table NHANVIEN (
    MANV      varchar2(10) primary key,
    HOTEN     varchar2(100),
    GIOITINH  varchar2(5),
    NGSINH    date,
    NGVL      date,
    CHUYENMON varchar2(20)
);
create table PHANCONG (
    MACB    varchar2(10),
    MANV    varchar2(10),
    NHIEMVU varchar2(50),
    constraint PK_PC primary key (MACB, MANV),
    constraint FK_PC_CB foreign key (MACB)
        references CHUYENBAY(MACB),
    constraint FK_PC_NV foreign key (MANV)
        references NHANVIEN(MANV)
);

insert into HANGHANGKHONG values
('VN','Vietnam Airlines', to_date('15/01/1956','dd/mm/yyyy'),52);

insert into HANGHANGKHONG values
('VJ','Vietjet Air', to_date('25/12/2011','dd/mm/yyyy'),33);

insert into HANGHANGKHONG values
('BL','Jetstar Pacific Airlines', to_date('01/12/1990','dd/mm/yyyy'),13);

insert into CHUYENBAY values
('VN550','VN','TP.HCM','Singapore',
 to_date('20/12/2025 13:15','dd/mm/yyyy hh24:mi'),2);

insert into CHUYENBAY values
('VJ331','VJ','Đà Nẵng','Vinh',
 to_date('28/12/2025 22:30','dd/mm/yyyy hh24:mi'),1);

insert into CHUYENBAY values
('BL696','BL','TP.HCM','Đà Lạt',
 to_date('24/12/2025 06:00','dd/mm/yyyy hh24:mi'),0.5);

insert into NHANVIEN values
('NV01','Lâm Văn Bền','Nam',
 to_date('10/09/1991','dd/mm/yyyy'),
 to_date('05/06/2021','dd/mm/yyyy'),
 'Phi công');

insert into NHANVIEN values
('NV02','Dương Thị Lục','Nữ',
 to_date('22/03/1989','dd/mm/yyyy'),
 to_date('12/11/2020','dd/mm/yyyy'),
 'Tiếp viên');

insert into NHANVIEN values
('NV03','Hoàng Thanh Tùng','Nam',
 to_date('29/07/1995','dd/mm/yyyy'),
 to_date('11/04/2022','dd/mm/yyyy'),
 'Tiếp viên');

insert into PHANCONG values ('VN550','NV01','Cơ trưởng');
insert into PHANCONG values ('VN550','NV02','Tiếp viên');
insert into PHANCONG values ('BL696','NV03','Tiếp viên trưởng');
// rang buoc toan ven
alter table NHANVIEN
add constraint CK_CHUYENMON
check (CHUYENMON in ('Phi công','Tiếp viên'));
//rang buoc
create or replace trigger TRG_NGAY_BAY
before insert or update on CHUYENBAY
for each row
declare
    v_ngtl date;
begin
    select NGTL into v_ngtl
    from HANGHANGKHONG
    where MAHANG = :new.MAHANG;

    if :new.BATDAU <= v_ngtl then
        raise_application_error(-20001,
        'Ngay bat dau phai lon hon ngay thanh lap hang');
    end if;
end;

// tim sn thang 7
select *
from NHANVIEN
where extract(month from NGSINH) = 7;

// chuyen bay co nhan vien nhieu nhat
select MACB
from PHANCONG
group by MACB
having count(MANV) = (
    select max(count(*))
    from PHANCONG
    group by MACB
);
// Với mỗi hãng hàng không, thống kê số chuyến bay có điểm xuất phát là ‘Đà Nẵng’ và có số nhân viên được phân công ít hơn 2
select h.MAHANG, h.TENHANG, count(cb.MACB) as SO_CHUYENBAY
from HANGHANGKHONG h
join CHUYENBAY cb on h.MAHANG = cb.MAHANG
left join PHANCONG pc on cb.MACB = pc.MACB
where cb.XUATPHAT = 'Đà Nẵng'
group by h.MAHANG, h.TENHANG, cb.MACB
having count(pc.MANV) < 2;

//nhân viên được phân công tham gia tất cả các chuyến bay
select nv.MANV, nv.HOTEN
from NHANVIEN nv
join PHANCONG pc on nv.MANV = pc.MANV
group by nv.MANV, nv.HOTEN
having count(distinct pc.MACB) = (
    select count(*) from CHUYENBAY
);

