CREATE TABLE Mathang (
    Mahang  VARCHAR2(5)  CONSTRAINT pk_mathang PRIMARY KEY,
    Tenhang VARCHAR2(50) NOT NULL,
    Soluong NUMBER(10)
);

CREATE TABLE Nhatkybanhang (
    Stt      NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    Ngay     DATE,
    Nguoimua VARCHAR2(50),
    Mahang   VARCHAR2(5) REFERENCES Mathang(Mahang),
    Soluong  NUMBER(10),
    Giaban   NUMBER(15,2)
);

INSERT INTO Mathang VALUES ('1', 'Hang A', 100);
INSERT INTO Mathang VALUES ('2', 'Hang B', 200);
INSERT INTO Mathang VALUES ('3', 'Hang C', 150);
COMMIT;


-- (a) trg_nhatkybanhang_insert
-- AFTER INSERT -> giảm Soluong trong MATHANG
CREATE OR REPLACE TRIGGER trg_nhatkybanhang_insert
AFTER INSERT ON Nhatkybanhang
FOR EACH ROW
BEGIN
    UPDATE Mathang
       SET Soluong = Soluong - :NEW.Soluong
     WHERE Mahang = :NEW.Mahang;
END trg_nhatkybanhang_insert;
/

-- TEST (a)
SELECT Soluong FROM Mathang WHERE Mahang = '1';  -- 100

INSERT INTO Nhatkybanhang(Ngay, Nguoimua, Mahang, Soluong, Giaban)
VALUES (SYSDATE, 'Nguyen Van A', '1', 20, 50000);
COMMIT;

SELECT Soluong FROM Mathang WHERE Mahang = '1';  --  80



-- (b) trg_nhatkybanhang_update_soluong
-- AFTER UPDATE OF Soluong -> điều chỉnh tồn kho
-- Mathang.Soluong = Soluong - (SoluongMoi - SoluongCu)

CREATE OR REPLACE TRIGGER trg_nhatkybanhang_update_soluong
AFTER UPDATE OF Soluong ON Nhatkybanhang
FOR EACH ROW
BEGIN
    UPDATE Mathang
       SET Soluong = Soluong - (:NEW.Soluong - :OLD.Soluong)
     WHERE Mahang = :NEW.Mahang;
END trg_nhatkybanhang_update_soluong;
/

-- TEST (b)
-- Giả sử bản ghi Stt=1 đang có Soluong=20, Mathang '1' = 80
UPDATE Nhatkybanhang SET Soluong = 30 WHERE Stt = 1;  -- Tăng 10 -> Mathang '1' = 70
COMMIT;
SELECT Soluong FROM Mathang WHERE Mahang = '1';       -- Kỳ vọng: 70

UPDATE Nhatkybanhang SET Soluong = 25 WHERE Stt = 1;  -- Giảm 5 -> Mathang '1' = 75
COMMIT;
SELECT Soluong FROM Mathang WHERE Mahang = '1';       -- Kỳ vọng: 75





-- (c) trg_nkbh_before_insert_check
-- BEFORE INSERT -> kiểm tra tồn kho trước
-- Nếu vượt tồn kho -> RAISE lỗi, hủy INSERT

DROP TRIGGER trg_nhatkybanhang_insert;

CREATE OR REPLACE TRIGGER trg_nkbh_before_insert_check
BEFORE INSERT ON Nhatkybanhang
FOR EACH ROW
DECLARE
    v_ton_kho NUMBER;
BEGIN
    -- Lấy tồn kho hiện tại
    SELECT Soluong
      INTO v_ton_kho
      FROM Mathang
     WHERE Mahang = :NEW.Mahang;

    -- Kiểm tra số lượng bán có hợp lệ không
    IF :NEW.Soluong > v_ton_kho THEN
        RAISE_APPLICATION_ERROR(-20003,
            'Lỗi: Số lượng bán (' || :NEW.Soluong ||
            ') vượt quá tồn kho (' || v_ton_kho || ') của mã hàng [' || :NEW.Mahang || '].');
    END IF;

    -- Hợp lệ -> giảm tồn kho (dùng BEFORE nên cập nhật ngay)
    UPDATE Mathang
       SET Soluong = Soluong - :NEW.Soluong
     WHERE Mahang = :NEW.Mahang;

END trg_nkbh_before_insert_check;
/

-- TEST (c)
SELECT Soluong FROM Mathang WHERE Mahang = '2';  -- Kỳ vọng: 200

-- Test hợp lệ
INSERT INTO Nhatkybanhang(Ngay, Nguoimua, Mahang, Soluong, Giaban)
VALUES (SYSDATE, 'Tran Thi B', '2', 50, 80000);
COMMIT;
SELECT Soluong FROM Mathang WHERE Mahang = '2';  -- Kỳ vọng: 150

-- Test vượt tồn kho -> lỗi -20003
INSERT INTO Nhatkybanhang(Ngay, Nguoimua, Mahang, Soluong, Giaban)
VALUES (SYSDATE, 'Le Van C', '2', 9999, 80000);





-- (d) Compound Trigger + Package biến đếm
-- UPDATE > 1 dòng -> lỗi
-- UPDATE đúng 1 dòng -> cập nhật Mathang

-- Tạo Package lưu biến đếm toàn cục
CREATE OR REPLACE PACKAGE pkg_nkbh_state AS
    g_update_count NUMBER := 0;
END pkg_nkbh_state;
/

-- DROP trigger (b) để tránh conflict với compound trigger
DROP TRIGGER trg_nhatkybanhang_update_soluong;

-- Tạo Compound Trigger
CREATE OR REPLACE TRIGGER trg_nkbh_update_compound
FOR UPDATE ON Nhatkybanhang
COMPOUND TRIGGER

    --  Trước toàn bộ câu lệnh: reset bộ đếm
    BEFORE STATEMENT IS
    BEGIN
        pkg_nkbh_state.g_update_count := 0;
    END BEFORE STATEMENT;

    --  Trước mỗi dòng: đếm + kiểm tra giới hạn
    BEFORE EACH ROW IS
    BEGIN
        pkg_nkbh_state.g_update_count := pkg_nkbh_state.g_update_count + 1;

        IF pkg_nkbh_state.g_update_count > 1 THEN
            RAISE_APPLICATION_ERROR(-20004,
                'Lỗi: Chỉ được phép UPDATE 1 bản ghi tại một thời điểm. ' ||
                'Câu lệnh đang tác động lên ' || pkg_nkbh_state.g_update_count || ' dòng.');
        END IF;
    END BEFORE EACH ROW;

    --  Sau mỗi dòng (chỉ đến được đây nếu đúng 1 dòng): cập nhật Mathang
    AFTER EACH ROW IS
    BEGIN
        -- Chỉ điều chỉnh khi cột Soluong thay đổi
        IF UPDATING('SOLUONG') THEN
            UPDATE Mathang
               SET Soluong = Soluong - (:NEW.Soluong - :OLD.Soluong)
             WHERE Mahang = :NEW.Mahang;
        END IF;
    END AFTER EACH ROW;

END trg_nkbh_update_compound;
/

-- TEST (d)
-- Test 1: Update đúng 1 dòng -> OK
UPDATE Nhatkybanhang SET Soluong = 40 WHERE Stt = 1;
COMMIT;

-- Test 2: Update nhiều dòng -> lỗi -20004
UPDATE Nhatkybanhang SET Soluong = 5 WHERE Mahang = '1';  -- Nếu có >1 dòng -> lỗi
ROLLBACK;




-- (e) Compound Trigger DELETE
-- DELETE > 1 dòng -> lỗi
-- DELETE đúng 1 dòng -> cộng lại tồn kho

-- Package tái dùng hoặc tạo biến riêng cho delete
CREATE OR REPLACE PACKAGE pkg_nkbh_del_state AS
    g_delete_count NUMBER := 0;
END pkg_nkbh_del_state;
/

CREATE OR REPLACE TRIGGER trg_nkbh_delete_compound
FOR DELETE ON Nhatkybanhang
COMPOUND TRIGGER

    BEFORE STATEMENT IS
    BEGIN
        pkg_nkbh_del_state.g_delete_count := 0;
    END BEFORE STATEMENT;

    BEFORE EACH ROW IS
    BEGIN
        pkg_nkbh_del_state.g_delete_count := pkg_nkbh_del_state.g_delete_count + 1;

        IF pkg_nkbh_del_state.g_delete_count > 1 THEN
            RAISE_APPLICATION_ERROR(-20005,
                'Lỗi: Chỉ được phép DELETE 1 bản ghi tại một thời điểm.');
        END IF;
    END BEFORE EACH ROW;

    AFTER EACH ROW IS
    BEGIN
        -- Hoàn trả tồn kho
        UPDATE Mathang
           SET Soluong = Soluong + :OLD.Soluong
         WHERE Mahang = :OLD.Mahang;
    END AFTER EACH ROW;

END trg_nkbh_delete_compound;
/

-- TEST (e)
SELECT Soluong FROM Mathang WHERE Mahang = '1';  -- Xem tồn kho trước

-- Test 1: Xóa đúng 1 dòng -> OK, tồn kho tăng lên
DELETE FROM Nhatkybanhang WHERE Stt = 1;
COMMIT;
SELECT Soluong FROM Mathang WHERE Mahang = '1';  -- Tồn kho tăng lại

-- Test 2: Xóa nhiều dòng -> lỗi -20005
-- (cần có nhiều dòng với Mahang='1' để test)
DELETE FROM Nhatkybanhang WHERE Mahang = '1';    -- Nếu >1 dòng -> lỗi
ROLLBACK;





-- (f) Compound Trigger UPDATE nâng cao
-- > 1 dòng -> lỗi
-- SoluongMoi < Tồn kho Mathang -> lỗi sai cập nhật  
-- SoluongMoi = Tồn kho Mathang -> thông báo không cần cập nhật
-- Hợp lệ -> cập nhật
CREATE OR REPLACE TRIGGER trg_nkbh_update_advanced
FOR UPDATE ON Nhatkybanhang
COMPOUND TRIGGER

    --  reset bộ đếm
    BEFORE STATEMENT IS
    BEGIN
        pkg_nkbh_state.g_update_count := 0;
    END BEFORE STATEMENT;

    -- đếm + chặn nếu > 1 dòng
    BEFORE EACH ROW IS
    BEGIN
        pkg_nkbh_state.g_update_count := pkg_nkbh_state.g_update_count + 1;

        IF pkg_nkbh_state.g_update_count > 1 THEN
            RAISE_APPLICATION_ERROR(-20004,
                'Lỗi: Chỉ được UPDATE 1 bản ghi tại một thời điểm.');
        END IF;
    END BEFORE EACH ROW;

    AFTER EACH ROW IS
        v_ton_kho_hien_tai NUMBER;   
        v_chenh_lech       NUMBER;  
    BEGIN
        IF UPDATING('SOLUONG') THEN
            SELECT Soluong
              INTO v_ton_kho_hien_tai
              FROM Mathang
             WHERE Mahang = :NEW.Mahang;

            v_chenh_lech := :NEW.Soluong - :OLD.Soluong;

            -- Số lượng mới < tồn kho -> lỗi sai cập nhật
            IF :NEW.Soluong < v_ton_kho_hien_tai THEN
                RAISE_APPLICATION_ERROR(-20006,
                    'Lỗi: Số lượng (' || :NEW.Soluong ||
                    ') nhỏ hơn tồn kho (' || v_ton_kho_hien_tai || '). Kiểm tra lại.');
            END IF;

            -- Số lượng mới = tồn kho -> không cần cập nhật
            IF :NEW.Soluong = v_ton_kho_hien_tai THEN
                RAISE_APPLICATION_ERROR(-20007,
                    'Thông báo: Số lượng bằng tồn kho (' || v_ton_kho_hien_tai ||
                    '). Không cần cập nhật.');
            END IF;

            -- Hợp lệ -> cập nhật Mathang
            UPDATE Mathang
               SET Soluong = Soluong - v_chenh_lech
             WHERE Mahang = :NEW.Mahang;
        END IF;
    END AFTER EACH ROW;

END trg_nkbh_update_advanced;
/
-- TEST (f)
-- Test 1: Update hợp lệ (SoluongMoi > tồn kho) -> OK
UPDATE Nhatkybanhang SET Soluong = 999 WHERE Stt = 2;
ROLLBACK;  -- Rollback để giữ dữ liệu test

-- Test 2: > 1 dòng -> lỗi -20004
UPDATE Nhatkybanhang SET Soluong = 10 WHERE Mahang = '2';
ROLLBACK;



-- (g) Procedure: proc_xoa_mathang
-- Nhận Mahang → kiểm tra tồn tại
-- Xóa NHATKYBANHANG trước, sau đó MATHANG
CREATE OR REPLACE PROCEDURE proc_xoa_mathang (
    p_mahang IN Mathang.Mahang%TYPE
) AS
    v_dem NUMBER;
BEGIN
    -- Kiểm tra Mahang có tồn tại không
    SELECT COUNT(*) INTO v_dem
      FROM Mathang
     WHERE Mahang = p_mahang;

    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Thông báo: Mã hàng [' || p_mahang || '] không tồn tại trong hệ thống.');
        RETURN;  -- Thoát thủ tục
    END IF;

    -- Xóa dữ liệu liên quan trong NHATKYBANHANG trước
    DELETE FROM Nhatkybanhang
     WHERE Mahang = p_mahang;

    DBMS_OUTPUT.PUT_LINE('Đã xóa ' || SQL%ROWCOUNT ||
                         ' bản ghi trong NHATKYBANHANG của mã hàng [' || p_mahang || '].');

    -- Xóa mặt hàng khỏi MATHANG
    DELETE FROM Mathang
     WHERE Mahang = p_mahang;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Đã xóa thành công mã hàng [' || p_mahang || '] khỏi MATHANG.');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Lỗi không xác định: ' || SQLERRM);
        RAISE;
END proc_xoa_mathang;
/

-- TEST (g)
SET SERVEROUTPUT ON;

-- Test 1: Mahang không tồn tại
EXEC proc_xoa_mathang('X999');

-- Test 2: Mahang tồn tại -> xóa cả 2 bảng
EXEC proc_xoa_mathang('3');

-- Kiểm tra
SELECT * FROM Mathang;
SELECT * FROM Nhatkybanhang WHERE Mahang = '3';





-- (h) Function: fn_TongTien
-- Nhận tên hàng -> tính SUM(Soluong × Giaban)
CREATE OR REPLACE FUNCTION fn_TongTien (
    p_tenhang IN VARCHAR2
) RETURN NUMBER AS
    v_tong NUMBER := 0;
BEGIN
    SELECT NVL(SUM(nk.Soluong * nk.Giaban), 0)
      INTO v_tong
      FROM Nhatkybanhang nk
      JOIN Mathang       mh ON nk.Mahang = mh.Mahang
     WHERE UPPER(mh.Tenhang) = UPPER(p_tenhang);  -- So sánh không phân biệt hoa thường

    RETURN v_tong;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0;
    WHEN OTHERS THEN
        RAISE;
END fn_TongTien;
/

-- TEST (h)
-- Thêm dữ liệu mẫu để test
INSERT INTO Nhatkybanhang(Ngay, Nguoimua, Mahang, Soluong, Giaban)
VALUES (SYSDATE, 'Khach A', '1', 10, 50000);
INSERT INTO Nhatkybanhang(Ngay, Nguoimua, Mahang, Soluong, Giaban)
VALUES (SYSDATE, 'Khach B', '1', 20, 55000);
INSERT INTO Nhatkybanhang(Ngay, Nguoimua, Mahang, Soluong, Giaban)
VALUES (SYSDATE, 'Khach C', '2', 15, 80000);
COMMIT;

-- 
SELECT fn_TongTien('Hang A') AS TongTien_HangA FROM DUAL;
-- (10×50000) + (20×55000) = 500000 + 1100000 = 1.600.000

SELECT fn_TongTien('Hang B') AS TongTien_HangB FROM DUAL;
-- 15 × 80000 = 1.200.000

SELECT fn_TongTien('Hang X') AS TongTien_HangX FROM DUAL;
--  0 (không tồn tại)

SELECT
    mh.Tenhang,
    fn_TongTien(mh.Tenhang) AS TongDoanhThu
FROM Mathang mh
ORDER BY mh.Mahang;





