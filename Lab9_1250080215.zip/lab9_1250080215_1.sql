CREATE TABLE Hang (
    Mahang   VARCHAR2(10) CONSTRAINT pk_hang PRIMARY KEY,
    Tenhang  VARCHAR2(50) NOT NULL,
    Soluong  NUMBER(10)   DEFAULT 0,
    Giaban   NUMBER(15,2)
);

CREATE TABLE Hoadon (
    Mahd       NUMBER        CONSTRAINT pk_hoadon PRIMARY KEY,
    Mahang     VARCHAR2(10)  REFERENCES Hang(Mahang),
    Soluongban NUMBER(10),
    Ngayban    DATE DEFAULT SYSDATE
);

-- Dữ liệu mẫu
INSERT INTO Hang VALUES ('H001', 'iPhone 15',   50,  25000000);
INSERT INTO Hang VALUES ('H002', 'Samsung S24', 30,  22000000);
INSERT INTO Hang VALUES ('H003', 'Xiaomi 14',   100, 12000000);
COMMIT;

-- ==
-- BÀI 1: trg_hoadon_insert
-- Kiểm tra Mahang tồn tại + đủ tồn kho
-- Nếu OK -> trừ Soluong
-- ==
CREATE OR REPLACE TRIGGER trg_hoadon_insert
BEFORE INSERT ON Hoadon
FOR EACH ROW
DECLARE
    v_soluong_ton NUMBER;
BEGIN
    -- Kiểm tra Mahang có tồn tại không
    BEGIN
        SELECT Soluong
          INTO v_soluong_ton
          FROM Hang
         WHERE Mahang = :NEW.Mahang;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20001,
                'Lỗi: Mã hàng [' || :NEW.Mahang || '] không tồn tại trong bảng HANG.');
    END;

    -- Kiểm tra số lượng tồn kho đủ không
    IF :NEW.Soluongban > v_soluong_ton THEN
        RAISE_APPLICATION_ERROR(-20002,
            'Lỗi: Số lượng bán (' || :NEW.Soluongban ||
            ') vượt quá tồn kho hiện tại (' || v_soluong_ton || ').');
    END IF;

    --Trừ tồn kho
    UPDATE Hang
       SET Soluong = Soluong - :NEW.Soluongban
     WHERE Mahang = :NEW.Mahang;

END trg_hoadon_insert;
/

-- ==
-- TEST BÀI 1
-- ==
-- Test 1: Hợp lệ -> thành công, tồn kho giảm
INSERT INTO Hoadon VALUES (1, 'H001', 5, SYSDATE);   -- OK: iPhone còn 50 -> 45
COMMIT;

-- Test 2: Mahang không tồn tại -> lỗi -20001
INSERT INTO Hoadon VALUES (2, 'H999', 1, SYSDATE);

-- Test 3: Vượt tồn kho -> lỗi -20002
INSERT INTO Hoadon VALUES (3, 'H002', 999, SYSDATE);

-- Kiểm tra tồn kho sau test
SELECT * FROM Hang;
SELECT * FROM Hoadon;





-- ==
-- BÀI 2: trg_hoadon_delete
-- Khi xóa hóa đơn -> cộng lại tồn kho
-- ==
CREATE OR REPLACE TRIGGER trg_hoadon_delete
AFTER DELETE ON Hoadon
FOR EACH ROW
BEGIN
    UPDATE Hang
       SET Soluong = Soluong + :OLD.Soluongban
     WHERE Mahang = :OLD.Mahang;
END trg_hoadon_delete;
/

-- ==
-- TEST BÀI 2
-- ==
-- Trước khi xóa: Hoadon 1 có 5 cái iPhone -> Hang H001 đang là 45
SELECT Soluong FROM Hang WHERE Mahang = 'H001';  -- Kỳ vọng: 45

DELETE FROM Hoadon WHERE Mahd = 1;
COMMIT;

-- Sau khi xóa: Tồn kho phải cộng lại 5 -> 50
SELECT Soluong FROM Hang WHERE Mahang = 'H001';  -- Kỳ vọng: 50





-- ==
-- BÀI 3: trg_hoadon_update
-- Khi UPDATE Soluongban -> điều chỉnh tồn kho
-- Soluong = Soluong - (SoluongMoi - SoluongCu)
-- ==
CREATE OR REPLACE TRIGGER trg_hoadon_update
AFTER UPDATE OF Soluongban ON Hoadon
FOR EACH ROW
DECLARE
    v_chenh_lech NUMBER;
BEGIN
    v_chenh_lech := :NEW.Soluongban - :OLD.Soluongban;

    UPDATE Hang
       SET Soluong = Soluong - v_chenh_lech
     WHERE Mahang = :NEW.Mahang;
END trg_hoadon_update;
/

-- ==
-- TEST BÀI 3
-- ==
-- Setup: Insert lại hóa đơn (trigger INSERT sẽ tự trừ tồn kho)
INSERT INTO Hoadon VALUES (10, 'H003', 10, SYSDATE);
COMMIT;
-- H003: 100 - 10 = 90

SELECT Soluong FROM Hang WHERE Mahang = 'H003';  -- 90

-- Update tăng số lượng bán từ 10 -> 15 (chênh lệch +5)
UPDATE Hoadon SET Soluongban = 15 WHERE Mahd = 10;
COMMIT;
-- H003: 90 - 5 = 85

SELECT Soluong FROM Hang WHERE Mahang = 'H003';  --  85

-- Update giảm số lượng bán từ 15 -> 8 (chênh lệch -7)
UPDATE Hoadon SET Soluongban = 8 WHERE Mahd = 10;
COMMIT;
-- H003: 85 - (-7) = 92

SELECT Soluong FROM Hang WHERE Mahang = 'H003';   92

